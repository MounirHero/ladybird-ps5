# Triplet vcpkg per la PS5: librerie statiche, compilate con il toolchain dell'SDK.
set(VCPKG_TARGET_ARCHITECTURE x64)
set(VCPKG_CRT_LINKAGE dynamic)
set(VCPKG_LIBRARY_LINKAGE static)
set(VCPKG_CMAKE_SYSTEM_NAME FreeBSD)
set(VCPKG_BUILD_TYPE release)
set(VCPKG_CHAINLOAD_TOOLCHAIN_FILE "${CMAKE_CURRENT_LIST_DIR}/../ps5.cmake")
set(VCPKG_ENV_PASSTHROUGH PS5_PAYLOAD_SDK)

# ICU (e ogni libreria con "configure" vecchio stile) chiede a config.sub di riconoscere la
# piattaforma. vcpkg le passa --host=prospero, che config.sub non conosce: la PS5 deriva da
# FreeBSD, quindi si dichiara quello. Senza questa riga: "config.sub prospero failed".
# Attenzione: va scritta come lista CMake (punto e virgola). Con lo spazio diventa un solo
# argomento e configure riceve --host="x86_64-unknown-freebsd --build=..." tutto insieme.
set(VCPKG_MAKE_BUILD_TRIPLET "--host=x86_64-unknown-freebsd;--build=x86_64-pc-linux-gnu")
