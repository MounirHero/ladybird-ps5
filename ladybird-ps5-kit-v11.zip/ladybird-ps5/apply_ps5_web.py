#!/usr/bin/env python3
"""Ladybird per PS5 - modalita' "motore web" (modello finale).

Prepara il sorgente per costruire i processi del motore (WebContent, RequestServer,
ImageDecoder) come payload PS5, senza interfaccia da PC.

Dichiarando FreeBSD, Ladybird chiederebbe Qt, X11, D-Bus, Vulkan, SDL, fontconfig: cose che
sulla PS5 non esistono. Qui si scrive una lista di dipendenze apposta, tutte senza condizioni
di piattaforma, e si spengono le parti che richiedono un ambiente desktop.

Idempotente: si puo' rilanciare. L'originale resta in vcpkg.json.completo.
"""
import json, os, shutil, sys

# Dipendenze per la PS5. Niente qtbase/qtpositioning/sdl3 (interfaccia desktop), niente
# dbus/libproxy (servizi di sistema Linux), niente vulkan/angle (grafica accelerata: Skia
# disegna via processore), niente fontconfig (i caratteri li fornisce PS Play), niente
# cpptrace/libdwarf/libedit (diagnostica da sviluppo).
DEPS = [
    "brotli", "fast-float", "fmt", "icu", "libpsl", "libtommath", "libxml2",
    "openssl", "simdjson", "simdutf", "sqlite3", "woff2", "wuffs", "zlib",
    "libjpeg-turbo",
    {"name": "libpng", "features": ["apng"]},
    {"name": "libwebp", "features": ["anim", "libwebpmux", "simd"]},
    {"name": "libavif", "features": ["dav1d"]},
    {"name": "tiff", "features": ["zstd"]},
    {"name": "mimalloc", "features": ["secure"]},
    {"name": "harfbuzz", "features": ["freetype", "icu"]},
    {"name": "skia", "features": ["freetype", "harfbuzz", "icu"]},
    {"name": "curl", "features": ["brotli", "non-http", "http2", "openssl", "websockets", "zstd"]},
    {"name": "ffmpeg", "features": ["avcodec", "avformat", "swresample", "dav1d", "zlib",
                                    "ladybird-components"]},
]

def main(src):
    vj = os.path.join(src, "vcpkg.json")
    bak = vj + ".completo"
    if not os.path.exists(bak):
        shutil.copyfile(vj, bak)
    d = json.load(open(bak, encoding="utf-8"))   # sempre dall'originale: idempotente
    d["dependencies"] = DEPS
    d.pop("default-features", None)
    json.dump(d, open(vj, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    print("Ladybird PS5, modalita' motore web")
    print("  vcpkg.json: %d dipendenze (erano %d; originale in vcpkg.json.completo)"
          % (len(DEPS), len(json.load(open(bak, encoding='utf-8'))["dependencies"])))
    for name in sorted(x if isinstance(x, str) else x["name"] for x in DEPS):
        print("    -", name)

if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else os.environ["LADYBIRD_SRC"])
