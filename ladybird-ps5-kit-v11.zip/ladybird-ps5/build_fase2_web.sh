#!/usr/bin/env bash
# Ladybird per PS5 - modello finale: il browser DENTRO PS Play, come thread.
# Niente payload esterni: i servizi di Ladybird (WebContent, RequestServer, ImageDecoder)
# diventano librerie statiche collegate nell'eseguibile di PS Play, ognuno nel proprio thread
# con il proprio ciclo di eventi; parlano fra loro con coppie di socket e memoria SHM_ANON
# (verificati sulla console dalla prova IPC).
#
# Perche' solo le dipendenze: sono 24 librerie grosse (Skia, FFmpeg, ICU, curl...), nessuna
# mai compilata per PS5. Costruirle da sole costa un giro di 1-2 ore; farlo insieme al motore
# non cambia il lavoro, ma allunga ogni errore. Quando passano tutte, lo stesso script
# prosegue da solo con WebContent e gli altri servizi.
set -uo pipefail
: "${PS5_PAYLOAD_SDK:?}"
: "${LADYBIRD_SRC:?}"
: "${VCPKG_ROOT:?}"
KIT="$(cd "$(dirname "$0")" && pwd)"
BUILD="$LADYBIRD_SRC/Build/ps5-web"

python3 "$KIT/apply_ps5_web.py" "$LADYBIRD_SRC"

echo "=== dipendenze per PS5 (la parte lunga) ==="
"$VCPKG_ROOT/vcpkg" install \
    --x-manifest-root="$LADYBIRD_SRC" \
    --x-install-root="$BUILD/vcpkg_installed" \
    --overlay-triplets="$KIT/toolchain/triplets" \
    --triplet=x64-ps5 --host-triplet=x64-linux \
    --x-buildtrees-root="$LADYBIRD_SRC/Build/bt" \
    --clean-after-build
rc=$?
echo "=== dipendenze: esito $rc ==="
[ $rc -ne 0 ] && exit $rc

echo "=== configurazione del motore ==="
cmake -S "$LADYBIRD_SRC" -B "$BUILD" -G Ninja \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_MAKE_PROGRAM="$(command -v ninja)" \
    -DCMAKE_TOOLCHAIN_FILE="$VCPKG_ROOT/scripts/buildsystems/vcpkg.cmake" \
    -DVCPKG_CHAINLOAD_TOOLCHAIN_FILE="$KIT/toolchain/ps5.cmake" \
    -DVCPKG_TARGET_TRIPLET=x64-ps5 \
    -DVCPKG_OVERLAY_TRIPLETS="$KIT/toolchain/triplets" \
    -DVCPKG_HOST_TRIPLET=x64-linux \
    -DVCPKG_INSTALLED_DIR="$BUILD/vcpkg_installed" \
    -DBUILD_SHARED_LIBS=OFF \
    -DENABLE_GUI_TARGETS=OFF \
    -DENABLE_JS_JIT=OFF \
    -DENABLE_CRANELIFT_JIT=OFF \
    -DLADYBIRD_ENABLE_CPPTRACE=OFF \
    -DENABLE_INSTALL_HEADERS=OFF \
    -DENABLE_INSTALL_FREEDESKTOP_FILES=OFF || exit $?

echo "=== librerie da incorporare in PS Play ==="
# i servizi come librerie (non come eseguibili): ognuno ha gia' il suo bersaglio statico
ninja -C "$BUILD" webcontentservice requestserverservice imagedecoderservice LibWebView || exit $?

echo "=== raccolta delle librerie ==="
OUTLIB="$BUILD/ps5-libs"
mkdir -p "$OUTLIB"
find "$BUILD" -name '*.a' -not -path '*/ps5-libs/*' -exec cp {} "$OUTLIB/" \;
find "$BUILD/vcpkg_installed/x64-ps5/lib" -name '*.a' -exec cp {} "$OUTLIB/" \; 2>/dev/null
ls -la "$OUTLIB" | head -60
du -sh "$OUTLIB"
