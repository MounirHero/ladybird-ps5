#!/usr/bin/env bash
# Ladybird per PS5, fase 1 - tutto il lavoro su GitHub Actions.
# Lanciato dal workflow .github/workflows/fase1-js.yml; non serve nessun computer.
set -uo pipefail
KIT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${GITHUB_WORKSPACE:-$PWD}/out"
mkdir -p "$OUT"
LOG="$OUT/build.log"
exec > >(tee -a "$LOG") 2>&1
step() { echo; echo "=============== $* ==============="; }
fail() { echo "::error::$*"; exit 1; }

step "1/8 spazio sul disco"
sudo rm -rf /usr/local/lib/android /usr/share/dotnet /opt/ghc /usr/local/share/boost \
            "${AGENT_TOOLSDIRECTORY:-/opt/hostedtoolcache}" /usr/local/share/powershell \
            /usr/share/swift /usr/local/lib/node_modules 2>/dev/null
sudo apt-get clean
df -h / | tail -1

step "2/8 strumenti di base"
sudo apt-get update -qq
sudo apt-get install -y -qq ninja-build cmake python3 curl zip unzip tar pkg-config \
                            autoconf automake libtool nasm bison flex gperf || fail "apt"
cmake --version | head -1

step "3/8 clang 21 (Ladybird richiede almeno il 19)"
# L'SDK non usa un clang proprio: i suoi script cercano nel sistema llvm-config-21,
# poi 20, 19... Quindi basta installare la 21 completa (clang, llvm, lld).
wget -qO /tmp/llvm.sh https://apt.llvm.org/llvm.sh && chmod +x /tmp/llvm.sh
sudo /tmp/llvm.sh 21 >/dev/null 2>&1 || true
sudo apt-get install -y -qq llvm-21 llvm-21-dev lld-21 clang-21 || true
for t in clang-21 clang++-21 llvm-config-21 ld.lld-21; do
    command -v "$t" >/dev/null || fail "manca $t"
done
clang-21 --version | head -1
llvm-config-21 --bindir

step "4/8 Rust per FreeBSD"
rustup update stable >/dev/null 2>&1 || true
rustup target add x86_64-unknown-freebsd || fail "bersaglio Rust FreeBSD"
rustc --version

step "5/8 SDK dei payload PS5"
# ATTENZIONE: $SDK/bin/clang NON e' un compilatore, e' uno script dell'SDK che aggiunge le
# opzioni per la PS5 e richiama il clang di sistema (cerca llvm-config-21, poi 20, 19...).
# Non va mai sovrascritto: basta avere clang 21 installato.
SRC="$HOME/ps5-sdk"
PREFIX="$HOME/ps5-sdk-install"
if [ ! -d "$SRC/.git" ]; then
    git clone --depth 1 https://github.com/ps5-payload-dev/sdk.git "$SRC" || fail "clone SDK"
fi
( cd "$SRC" && make -j"$(nproc)" >/tmp/sdk.log 2>&1 ) \
    || { tail -40 /tmp/sdk.log; cp /tmp/sdk.log "$OUT/"; fail "compilazione SDK"; }
# l'SDK si usa installato: senza "make install" la cartella bin/ puo' non esserci
( cd "$SRC" && make install PREFIX="$PREFIX" >>/tmp/sdk.log 2>&1 ) \
    || ( cd "$SRC" && sudo make install >>/tmp/sdk.log 2>&1 ) || true
cp /tmp/sdk.log "$OUT/" 2>/dev/null

# dove e' finito davvero: si cerca lo script prospero-clang
PS5_PAYLOAD_SDK=""
for d in "$PREFIX" /opt/ps5-payload-sdk "$SRC"; do
    [ -x "$d/bin/prospero-clang" ] && { PS5_PAYLOAD_SDK="$d"; break; }
done
if [ -z "$PS5_PAYLOAD_SDK" ]; then
    found=$(find "$HOME" /opt /usr/local -name prospero-clang -type f 2>/dev/null | head -1)
    [ -n "$found" ] && PS5_PAYLOAD_SDK="$(cd "$(dirname "$found")/.." && pwd)"
fi
if [ -z "$PS5_PAYLOAD_SDK" ]; then
    echo "--- contenuto di $SRC:"; ls -la "$SRC"
    echo "--- contenuto di $PREFIX:"; ls -la "$PREFIX" 2>/dev/null
    echo "--- come si installa (Makefile):"; grep -nE '^install|^PREFIX|^DESTDIR' "$SRC/Makefile" | head
    echo "--- ultime righe della compilazione dell'SDK:"; tail -40 /tmp/sdk.log
    fail "SDK: non trovo bin/prospero-clang (vedi l'elenco qui sopra)"
fi
export PS5_PAYLOAD_SDK
echo "SDK in uso: $PS5_PAYLOAD_SDK"
ls "$PS5_PAYLOAD_SDK/bin" | head -30
"$PS5_PAYLOAD_SDK/bin/clang" --version | head -2 || fail "lo script clang dell'SDK non funziona"

step "6/8 sorgente di Ladybird"
if [ -d "$GITHUB_WORKSPACE/ladybird/.git" ]; then
    export LADYBIRD_SRC="$GITHUB_WORKSPACE/ladybird"      # gia' nel repository
else
    git clone --depth 1 https://github.com/LadybirdBrowser/ladybird.git "$HOME/ladybird" \
        || fail "clone di Ladybird"
    export LADYBIRD_SRC="$HOME/ladybird"
fi
( cd "$LADYBIRD_SRC" && git log -1 --format='Ladybird %h del %ci' )

step "7/8 vcpkg"
if [ ! -d "$HOME/vcpkg/.git" ]; then
    git clone --depth 1 https://github.com/microsoft/vcpkg.git "$HOME/vcpkg" || fail "clone vcpkg"
fi
"$HOME/vcpkg/bootstrap-vcpkg.sh" -disableMetrics >/dev/null || fail "bootstrap vcpkg"
export VCPKG_ROOT="$HOME/vcpkg"

step "8/8 compilazione"
chmod +x "$KIT/build_fase1_js.sh" "$KIT/check_symbols.sh"
"$KIT/build_fase1_js.sh"
rc=$?

step "risultati"
find "$LADYBIRD_SRC/Build" -name 'js' -type f -o -name 'js*.elf' 2>/dev/null | head -5 \
    | while read -r f; do cp "$f" "$OUT/"; echo "prodotto: $f"; done
# gli errori di vcpkg sono i piu' utili al primo tentativo
find "$HOME/vcpkg/buildtrees" -name '*-err.log' -size +0 2>/dev/null | head -30 \
    | tar czf "$OUT/vcpkg-errori.tar.gz" -T - 2>/dev/null
df -h / | tail -1
ls -la "$OUT"
[ "$rc" = 0 ] && echo "FASE 1 RIUSCITA" || echo "FASE 1 FALLITA (e' normale al primo giro: mandami build.log)"
exit "$rc"
