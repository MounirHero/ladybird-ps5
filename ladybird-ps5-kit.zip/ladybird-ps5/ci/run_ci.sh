#!/usr/bin/env bash
# Ladybird per PS5, fase 1 - tutto il lavoro su GitHub Actions.
# Lanciato dal workflow .github/workflows/fase1-js.yml; non serve nessun computer.
set -uo pipefail
KIT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${GITHUB_WORKSPACE:-$PWD}/out"
mkdir -p "$OUT"
LOG="$OUT/build.log"
exec > >(tee -a "$LOG") 2>&1
step() { echo; echo "=============== $* ==============="; }
fail() { echo "::error::$*"; exit 1; }

KIT_VERSION="10 - 11 ottobre, browser dentro PS Play"
echo "### KIT VERSIONE $KIT_VERSION"
echo "### script: $KIT/ci/run_ci.sh"

step "1/8 spazio sul disco"
sudo rm -rf /usr/local/lib/android /usr/share/dotnet /opt/ghc /usr/local/share/boost \
            "${AGENT_TOOLSDIRECTORY:-/opt/hostedtoolcache}" /usr/local/share/powershell \
            /usr/share/swift /usr/local/lib/node_modules 2>/dev/null
sudo apt-get clean
df -h / | tail -1

step "2/8 strumenti di base"
sudo apt-get update -qq
sudo apt-get install -y -qq ninja-build cmake python3 curl zip unzip tar pkg-config \
                            autoconf automake libtool nasm bison flex gperf || fail "apt"
cmake --version | head -1

step "3/8 clang 21 (Ladybird richiede almeno il 19)"
# L'SDK non usa un clang proprio: i suoi script cercano nel sistema llvm-config-21,
# poi 20, 19... Quindi basta installare la 21 completa (clang, llvm, lld).
wget -qO /tmp/llvm.sh https://apt.llvm.org/llvm.sh && chmod +x /tmp/llvm.sh
sudo /tmp/llvm.sh 21 >/dev/null 2>&1 || true
sudo apt-get install -y -qq llvm-21 llvm-21-dev lld-21 clang-21 || true
for t in clang-21 clang++-21 llvm-config-21 ld.lld-21; do
    command -v "$t" >/dev/null || fail "manca $t"
done
clang-21 --version | head -1
llvm-config-21 --bindir

step "4/8 Rust per FreeBSD"
rustup update stable >/dev/null 2>&1 || true
rustup target add x86_64-unknown-freebsd || fail "bersaglio Rust FreeBSD"
rustc --version

step "5/8 SDK dei payload PS5"
# ATTENZIONE: $SDK/bin/clang NON e' un compilatore, e' uno script dell'SDK che aggiunge le
# opzioni per la PS5 e richiama il clang di sistema (cerca llvm-config-21, poi 20, 19...).
# Non va mai sovrascritto: basta avere clang 21 installato.
SRC="$HOME/ps5-sdk"
PREFIX="$HOME/ps5-sdk-install"
if [ ! -d "$SRC/.git" ]; then
    git clone --depth 1 https://github.com/ps5-payload-dev/sdk.git "$SRC" || fail "clone SDK"
fi
( cd "$SRC" && make -j"$(nproc)" >/tmp/sdk.log 2>&1 ) \
    || { tail -40 /tmp/sdk.log; cp /tmp/sdk.log "$OUT/"; fail "compilazione SDK"; }
# l'SDK si usa installato: senza "make install" la cartella bin/ puo' non esserci
( cd "$SRC" && make install PREFIX="$PREFIX" >>/tmp/sdk.log 2>&1 ) \
    || ( cd "$SRC" && sudo make install >>/tmp/sdk.log 2>&1 ) || true
cp /tmp/sdk.log "$OUT/" 2>/dev/null

# dove e' finito davvero: si cerca lo script prospero-clang
PS5_PAYLOAD_SDK=""
for d in "$PREFIX" /opt/ps5-payload-sdk "$SRC"; do
    [ -x "$d/bin/prospero-clang" ] && { PS5_PAYLOAD_SDK="$d"; break; }
done
if [ -z "$PS5_PAYLOAD_SDK" ]; then
    found=$(find "$HOME" /opt /usr/local -name prospero-clang -type f 2>/dev/null | head -1)
    [ -n "$found" ] && PS5_PAYLOAD_SDK="$(cd "$(dirname "$found")/.." && pwd)"
fi
if [ -z "$PS5_PAYLOAD_SDK" ]; then
    echo "--- contenuto di $SRC:"; ls -la "$SRC"
    echo "--- contenuto di $PREFIX:"; ls -la "$PREFIX" 2>/dev/null
    echo "--- come si installa (Makefile):"; grep -nE '^install|^PREFIX|^DESTDIR' "$SRC/Makefile" | head
    echo "--- ultime righe della compilazione dell'SDK:"; tail -40 /tmp/sdk.log
    fail "SDK: non trovo bin/prospero-clang (vedi l'elenco qui sopra)"
fi
export PS5_PAYLOAD_SDK
echo "SDK in uso: $PS5_PAYLOAD_SDK"
ls "$PS5_PAYLOAD_SDK/bin" | head -30
"$PS5_PAYLOAD_SDK/bin/clang" --version | head -2 || fail "lo script clang dell'SDK non funziona"

# PROVA C++: le intestazioni standard (type_traits, algorithm...) le fornisce l'SDK stesso in
# target/include/c++/v1. Se mancano, ogni libreria C++ fallisce a meta' di vcpkg con un errore
# poco chiaro: meglio accorgersene adesso.
cat > /tmp/provacxx.cpp <<'CXXEOF'
#include <type_traits>
#include <algorithm>
int main() { return std::is_same_v<int, int> ? 0 : 1; }
CXXEOF
prova_cxx() {
    "$PS5_PAYLOAD_SDK/bin/prospero-clang++" -c /tmp/provacxx.cpp -o /tmp/provacxx.o 2>/tmp/provacxx.log
}
if ! prova_cxx; then
    echo "C++ non disponibile: installo libc++ dell'SDK (lo script libcxx.sh del sorgente)"
    echo "--- libcxx.sh (prime 40 righe):"; head -40 "$SRC/libcxx.sh" 2>&1
    echo "--- ci.sh (come fa la compilazione ufficiale):"; head -30 "$SRC/ci.sh" 2>&1
    # puo' richiedere di scrivere in /opt: si prova prima senza sudo, poi con
    ( cd "$SRC" && PS5_PAYLOAD_SDK="$PS5_PAYLOAD_SDK" bash libcxx.sh >/tmp/libcxx.log 2>&1 ) \
      || ( cd "$SRC" && sudo -E PS5_PAYLOAD_SDK="$PS5_PAYLOAD_SDK" bash libcxx.sh >>/tmp/libcxx.log 2>&1 ) \
      || true
    tail -25 /tmp/libcxx.log
    cp /tmp/libcxx.log "$OUT/" 2>/dev/null
fi
if prova_cxx; then
    echo "C++ per PS5: OK"
    "$PS5_PAYLOAD_SDK/bin/prospero-clang++" -v -c /tmp/provacxx.cpp -o /tmp/provacxx.o 2>&1 \
        | sed -n '/#include <...> search starts here/,/End of search list/p'
else
    echo "--- errore:"; cat /tmp/provacxx.log
    echo "--- intestazioni C++ dell'SDK:"; ls "$PS5_PAYLOAD_SDK/target/include/c++/v1" 2>&1 | head -5
    echo "--- libcxx.sh completo:"; cat "$SRC/libcxx.sh" 2>&1 | head -80
    echo "--- registro di libcxx.sh:"; tail -40 /tmp/libcxx.log 2>/dev/null
    fail "l'SDK non compila C++ nemmeno dopo libcxx.sh (vedi sopra)"
fi

step "6/8 sorgente di Ladybird"
if [ -d "$GITHUB_WORKSPACE/ladybird/.git" ]; then
    export LADYBIRD_SRC="$GITHUB_WORKSPACE/ladybird"      # gia' nel repository
else
    git clone --depth 1 https://github.com/LadybirdBrowser/ladybird.git "$HOME/ladybird" \
        || fail "clone di Ladybird"
    export LADYBIRD_SRC="$HOME/ladybird"
fi
( cd "$LADYBIRD_SRC" && git log -1 --format='Ladybird %h del %ci' )

step "7/8 vcpkg"
# NIENTE --depth 1: Ladybird fissa la versione delle librerie con un commit preciso
# ("builtin-baseline") e vcpkg deve poterlo leggere nella propria storia git. Con una copia
# superficiale fallisce con: fatal: failed to unpack tree object <commit>
if [ -d "$HOME/vcpkg/.git" ]; then
    # una copia rimasta da prima: se e' superficiale o parziale, si completa
    if [ "$(git -C "$HOME/vcpkg" rev-parse --is-shallow-repository 2>/dev/null)" = true ]; then
        git -C "$HOME/vcpkg" fetch --unshallow --tags origin --quiet \
            || git -C "$HOME/vcpkg" fetch --depth=2147483647 --tags origin --quiet \
            || { rm -rf "$HOME/vcpkg"; }
    fi
fi
if [ ! -d "$HOME/vcpkg/.git" ]; then
    # clone completo, senza --depth e senza --filter: l'installazione a manifesto legge
    # la storia (versions/baseline.json e i commit delle singole librerie)
    git clone https://github.com/microsoft/vcpkg.git "$HOME/vcpkg" || fail "clone vcpkg"
fi
git -C "$HOME/vcpkg" show HEAD:versions/baseline.json >/dev/null 2>&1 \
    || fail "vcpkg: la storia e' incompleta, versions/baseline.json non leggibile"
"$HOME/vcpkg/bootstrap-vcpkg.sh" -disableMetrics >/dev/null || fail "bootstrap vcpkg"
export VCPKG_ROOT="$HOME/vcpkg"
# verifica che la versione richiesta da Ladybird ci sia davvero
base=$(python3 -c "import json,sys;print(json.load(open(sys.argv[1])).get('builtin-baseline',''))" \
       "$LADYBIRD_SRC/vcpkg.json" 2>/dev/null)
if [ -n "$base" ]; then
    ( cd "$HOME/vcpkg" && git cat-file -e "$base^{tree}" 2>/dev/null ) \
        && echo "versione delle librerie ${base:0:10}: presente" \
        || { ( cd "$HOME/vcpkg" && git fetch --unshallow --quiet 2>/dev/null; \
               git fetch origin "$base" --quiet 2>/dev/null ) ; \
             echo "versione ${base:0:10}: recuperata a parte"; }
fi

step "8/8 compilazione"
# MODO=web (predefinito): il modello finale, i processi del motore come payload PS5.
# MODO=js: solo l'interprete JavaScript, piu' rapido da far fallire (collaudo).
MODO="${LADYBIRD_PS5_MODO:-web}"
echo "modalita': $MODO"
chmod +x "$KIT"/*.sh
if [ "$MODO" = js ]; then
    "$KIT/build_fase1_js.sh"
else
    "$KIT/build_fase2_web.sh"
fi
rc=$?

step "risultati"
find "$LADYBIRD_SRC/Build" -name 'js' -type f 2>/dev/null | head -2 \
    | while read -r f; do cp "$f" "$OUT/"; echo "prodotto: $f"; done
# le librerie per PS Play, se ci sono
[ -d "$LADYBIRD_SRC/Build/ps5-web/ps5-libs" ] && tar czf "$OUT/ladybird-ps5-libs.tar.gz" \
    -C "$LADYBIRD_SRC/Build/ps5-web" ps5-libs && echo "librerie raccolte in ladybird-ps5-libs.tar.gz"
# gli errori di vcpkg sono i piu' utili al primo tentativo
find "$HOME/vcpkg/buildtrees" -name '*-err.log' -size +0 2>/dev/null | head -30 \
    | tar czf "$OUT/vcpkg-errori.tar.gz" -T - 2>/dev/null
df -h / | tail -1
ls -la "$OUT"
[ "$rc" = 0 ] && echo "FASE 1 RIUSCITA" || echo "FASE 1 FALLITA (e' normale al primo giro: mandami build.log)"
exit "$rc"
