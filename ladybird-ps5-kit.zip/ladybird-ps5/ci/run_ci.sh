#!/usr/bin/env bash
# Ladybird per PS5, fase 1 - tutto il lavoro su GitHub Actions.
# Lanciato dal workflow .github/workflows/fase1-js.yml; non serve nessun computer.
set -uo pipefail
KIT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${GITHUB_WORKSPACE:-$PWD}/out"
mkdir -p "$OUT"
LOG="$OUT/build.log"
exec > >(tee -a "$LOG") 2>&1
step() { echo; echo "=============== $* ==============="; }
fail() { echo "::error::$*"; exit 1; }

step "1/8 spazio sul disco"
sudo rm -rf /usr/local/lib/android /usr/share/dotnet /opt/ghc /usr/local/share/boost \
            "${AGENT_TOOLSDIRECTORY:-/opt/hostedtoolcache}" /usr/local/share/powershell \
            /usr/share/swift /usr/local/lib/node_modules 2>/dev/null
sudo apt-get clean
df -h / | tail -1

step "2/8 strumenti di base"
sudo apt-get update -qq
sudo apt-get install -y -qq ninja-build cmake python3 curl zip unzip tar pkg-config \
                            autoconf automake libtool nasm bison flex gperf || fail "apt"
cmake --version | head -1

step "3/8 clang 21 (Ladybird richiede almeno il 19)"
wget -qO /tmp/llvm.sh https://apt.llvm.org/llvm.sh && chmod +x /tmp/llvm.sh
sudo /tmp/llvm.sh 21 >/dev/null 2>&1 || true
command -v clang-21 >/dev/null || fail "clang 21 non installato"
clang-21 --version | head -1

step "4/8 Rust per FreeBSD"
rustup update stable >/dev/null 2>&1 || true
rustup target add x86_64-unknown-freebsd || fail "bersaglio Rust FreeBSD"
rustc --version

step "5/8 SDK dei payload PS5"
if [ ! -d "$HOME/ps5-sdk/.git" ]; then
    git clone --depth 1 https://github.com/ps5-payload-dev/sdk.git "$HOME/ps5-sdk" || fail "clone SDK"
fi
( cd "$HOME/ps5-sdk" && make -j"$(nproc)" >/tmp/sdk.log 2>&1 ) || { tail -30 /tmp/sdk.log; fail "compilazione SDK"; }
cp /tmp/sdk.log "$OUT/" 2>/dev/null
# Ladybird richiede clang >= 19: l'SDK usa quello che trova qui dentro
ln -sf "$(command -v clang-21)"   "$HOME/ps5-sdk/bin/clang"
ln -sf "$(command -v clang++-21)" "$HOME/ps5-sdk/bin/clang++"
export PS5_PAYLOAD_SDK="$HOME/ps5-sdk"

step "6/8 sorgente di Ladybird"
if [ -d "$GITHUB_WORKSPACE/ladybird/.git" ]; then
    export LADYBIRD_SRC="$GITHUB_WORKSPACE/ladybird"      # gia' nel repository
else
    git clone --depth 1 https://github.com/LadybirdBrowser/ladybird.git "$HOME/ladybird" \
        || fail "clone di Ladybird"
    export LADYBIRD_SRC="$HOME/ladybird"
fi
( cd "$LADYBIRD_SRC" && git log -1 --format='Ladybird %h del %ci' )

step "7/8 vcpkg"
if [ ! -d "$HOME/vcpkg/.git" ]; then
    git clone --depth 1 https://github.com/microsoft/vcpkg.git "$HOME/vcpkg" || fail "clone vcpkg"
fi
"$HOME/vcpkg/bootstrap-vcpkg.sh" -disableMetrics >/dev/null || fail "bootstrap vcpkg"
export VCPKG_ROOT="$HOME/vcpkg"

step "8/8 compilazione"
chmod +x "$KIT/build_fase1_js.sh" "$KIT/check_symbols.sh"
"$KIT/build_fase1_js.sh"
rc=$?

step "risultati"
find "$LADYBIRD_SRC/Build" -name 'js' -type f -o -name 'js*.elf' 2>/dev/null | head -5 \
    | while read -r f; do cp "$f" "$OUT/"; echo "prodotto: $f"; done
# gli errori di vcpkg sono i piu' utili al primo tentativo
find "$HOME/vcpkg/buildtrees" -name '*-err.log' -size +0 2>/dev/null | head -30 \
    | tar czf "$OUT/vcpkg-errori.tar.gz" -T - 2>/dev/null
df -h / | tail -1
ls -la "$OUT"
[ "$rc" = 0 ] && echo "FASE 1 RIUSCITA" || echo "FASE 1 FALLITA (e' normale al primo giro: mandami build.log)"
exit "$rc"
