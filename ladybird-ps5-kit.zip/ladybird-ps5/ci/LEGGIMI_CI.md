# Compilare senza un computer: GitHub Actions

Serve solo un browser e un account gratuito su github.com.

## Preparazione (una volta sola)

1. Crea un repository **privato** su GitHub, per esempio `ladybird-ps5`.
2. Caricaci dentro:
   - il sorgente di Ladybird (il contenuto di `ladybird-master`, non la cartella stessa);
   - la cartella `ladybird-ps5/` (questo kit) nella radice;
   - il file `ci/fase1-js.yml` rinominato in **`.github/workflows/fase1-js.yml`**.
3. Da telefono conviene caricare il sorgente con l'app GitHub oppure, più comodo, usare
   "Import repository" da un file zip su un servizio di hosting.

## Lanciare la compilazione

Scheda **Actions** → "Ladybird PS5 - fase 1 (js)" → **Run workflow**.
Dura una o due ore. Puoi chiudere la pagina: continua da sola.

## Leggere il risultato

In fondo alla pagina del lavoro, sotto **Artifacts**, scarichi `ladybird-ps5-fase1`:
- `js.elf` → il payload da provare sulla PS5 (se la compilazione è riuscita);
- `build.log` → il registro completo;
- `vcpkg-errori.tar.gz` → gli errori delle librerie, i più utili al primo tentativo.

## Cosa aspettarsi

Il primo tentativo quasi certamente **fallisce**: è previsto. Serve a raccogliere gli errori
veri, che qui non posso vedere perché non ho rete né spazio. Mandami `build.log` e correggo.
In genere servono due o tre giri.

## Limiti da sapere

- Ogni lavoro può durare al massimo 6 ore (qui ne bastano 2).
- Su repository privato ci sono 2000 minuti gratis al mese; su repository pubblico è illimitato.
- Il disco della macchina è stretto: il primo passo libera spazio, ma se finisce lo vedrai nel log.
