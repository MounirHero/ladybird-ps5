# Ladybird per PS5 — fasi 2, 3 e 4

## Cosa dice il sorgente (verificato)
- **Modalità senza interfaccia già presente** in LibWebView (`--headless`): `screenshot`
  (predefinita, con `--screenshot-path`), `text`, `layout-tree`, `manual`. La vista è
  `LibWebView/HeadlessWebView`.
- **Processi**: interfaccia, WebContent (uno per scheda), RequestServer (rete), ImageDecoder,
  più WebWorker e altri. Il figlio riceve il canale IPC **per eredità**: il padre crea un
  `socketpair`, il figlio eredita un'estremità e la ritrova con la variabile d'ambiente
  `SOCKET_TAKEOVER=nome:fd` (`LibWebView/Process.cpp`). Con elfldr un payload **non eredita**
  né descrittori né variabili d'ambiente: questo è il punto da adattare.
- L'IPC di Ladybird **passa descrittori** fra processi (memoria condivisa per le immagini delle
  pagine), quindi servono `SCM_RIGHTS` su socket locali e memoria condivisa anonima **fra
  processi diversi**. Nello stesso processo la PS5 li supporta (verificato con la diagnosi Wine);
  fra due payload va provato.

## Fase 2 — una pagina salvata come immagine
Un **frontend PS5 nostro** (`UI/PS5/main.cpp`, sul modello di quello Android) che avvia
`WebView::Application` in modalità `--headless=screenshot` e salva in `/data/ps_play/ladybird/`.
Dipendenze in più rispetto alla fase 1: LibWeb, LibGfx, Skia (solo rendering software),
HarfBuzz, FreeType/fontconfig o un elenco di font fisso, cURL (RequestServer), decodificatori
d'immagine. Prima prova consigliata: `--headless=text` su una pagina locale, che non richiede
né rete né immagini.

## Fase 3 — i processi sulla PS5
Proposta: **ogni servizio è un payload** (WebContent.elf, RequestServer.elf, ImageDecoder.elf)
avviato tramite elfldr, e il canale si crea **al contrario**:
1. il padre apre un socket locale in ascolto su `/data/ps_play/ladybird/ipc/<servizio>-<n>.sock`
2. invia l'ELF del servizio a elfldr (porta 9021)
3. il figlio, senza `SOCKET_TAKEOVER`, si collega a quel percorso (scritto in un piccolo file
   "biglietto" accanto al socket, perché elfldr non passa argomenti)
4. il padre accetta la connessione e la usa come `IPC::Transport`, esattamente come oggi
Modifiche: `Process::spawn` (lato padre) e la presa in carico del socket nel figlio, sotto
`LADYBIRD_PS5`. Alternativa da tenere di riserva: servizi come thread nello stesso processo
(più semplice per i descrittori, ma Ladybird ha stato globale per processo).

**Prova di fattibilità da fare prima**: due payload che si collegano su un socket locale, si
passano un descrittore di memoria condivisa con `SCM_RIGHTS` e ci scrivono a turno. Se
funziona, la fase 3 è solo lavoro; se no, si passa ai thread.

## Fase 4 — dentro PS Play (pronta lato PS Play, v7.63)
- Protocollo `frameshare.h`: intestazione + 3 buffer RGBA8, coda di 256 eventi verso il
  produttore, titolo/URL/stato, battiti di vita. File mappato in `/data/ps_play/ladybird/`.
- Pagina **Ladybird** in PS Play (Media & tools): mostra i fotogrammi, cursore con levetta o
  croce, Croce = clic, L1/R1 e levetta destra = scorrimento, Triangolo = indirizzo.
- `ppfs_demo.c`: produttore di prova. Il frontend PS5 di Ladybird farà lo stesso:
  `ppfs_create()`, disegno nel buffer di `ppfs_back()`, `ppfs_publish()`, eventi con
  `ppfs_pop_event()` tradotti in eventi di Ladybird.
