#!/usr/bin/env bash
# Simboli che il binario importa e che nessuna libreria dell'SDK PS5 fornisce.
# Sulla console una funzione mancante non da' errore al caricamento: la chiamata salta
# all'indirizzo 0 (e' cosi' che abbiamo trovato umask & co. in PS Play e i simboli di Wine).
set -euo pipefail
BIN="${1:?uso: check_symbols.sh <binario>}"
: "${PS5_PAYLOAD_SDK:?imposta PS5_PAYLOAD_SDK}"
NM="$(command -v llvm-nm || command -v nm)"
tmp="$(mktemp -d)"
"$NM" -D --undefined-only "$BIN" 2>/dev/null | awk '{print $NF}' | sed 's/@.*//' | sort -u > "$tmp/und"
for so in "$PS5_PAYLOAD_SDK"/target/lib/*.so; do
    "$NM" -D --defined-only "$so" 2>/dev/null | awk '{print $NF}'
done | sed 's/@.*//' | sort -u > "$tmp/sdk"
comm -23 "$tmp/und" "$tmp/sdk" > "$tmp/missing"
echo "importati: $(wc -l < "$tmp/und")   non forniti dall'SDK: $(wc -l < "$tmp/missing")"
cat "$tmp/missing"
if grep -qxE 'umask|fork|openat|fstatat|fchdir|symlink|unlinkat|lchown|fchown' "$tmp/missing"; then
    echo
    echo "Alcuni sono in libkernel_sys, che i payload non caricano: aggiungi ps5_compat/kernel_sys_compat.c"
fi
rm -rf "$tmp"
