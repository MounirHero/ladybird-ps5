/* PS Play - trasporto dei fotogrammi fra processi (fase 4 del browser Ladybird).
 *
 * Un PRODUTTORE (oggi il payload dimostrativo, poi il frontend PS5 di Ladybird) disegna
 * pagine in memoria; PS Play, il CONSUMATORE, le mostra come texture e gli rimanda l'input.
 * I due sono processi diversi: il produttore gira come payload lanciato da elfldr.
 *
 * Memoria condivisa: un unico blocco con intestazione + 3 buffer RGBA8 (triplo buffer, cosi'
 * il produttore non scrive mai nel buffer che il consumatore sta leggendo).
 * Dove sta il blocco lo decide il produttore e lo scrive in PPFS_LOCATOR:
 *   "shm:/nome"      memoria condivisa POSIX (shm_open) - l'unico formato accettato dalla v2
 *   "file:/percorso" v1, NON piu' supportato: file in /data mappati in condivisione, sospettati
 *                    di aver spento la console
 * Il consumatore legge il localizzatore: niente ambiguita' fra i due metodi.
 *
 * Header in C puro: si include sia dal C del payload sia dal C++ di PS Play.
 */
#ifndef PSPLAY_FRAMESHARE_H
#define PSPLAY_FRAMESHARE_H

#include <stddef.h>
#include <stdint.h>

#define PPFS_MAGIC 0x53465050u /* "PPFS" */
#define PPFS_VERSION 1u
#define PPFS_MAX_W 1920u
#define PPFS_MAX_H 1080u
#define PPFS_BUFFERS 3u
#define PPFS_EVENTS 256u
#ifndef PPFS_DIR
#define PPFS_DIR "/data/ps_play/ladybird" /* sul PC, per le prove: -DPPFS_DIR=... */
#endif
#define PPFS_LOCATOR PPFS_DIR "/frames.where"
#define PPFS_SHM_NAME "/psplay_ladybird"
#define PPFS_FILE PPFS_DIR "/frames.bin"

/* eventi dal consumatore (PS Play) al produttore */
enum ppfs_event_type
{
    PPFS_EV_NONE = 0,
    PPFS_EV_BUTTON_DOWN = 1, /* code = PPFS_BTN_* */
    PPFS_EV_BUTTON_UP = 2,
    PPFS_EV_POINTER_MOVE = 3, /* x, y in pixel del fotogramma */
    PPFS_EV_SCROLL = 4,       /* x, y = spostamento */
    PPFS_EV_KEY_TEXT = 5,     /* code = carattere Unicode */
    PPFS_EV_NAVIGATE = 6,     /* l'URL sta in ppfs_header.cmd_url */
    PPFS_EV_BACK = 7,
    PPFS_EV_FORWARD = 8,
    PPFS_EV_RELOAD = 9,
    PPFS_EV_QUIT = 10
};
enum ppfs_button
{
    PPFS_BTN_CROSS = 1,
    PPFS_BTN_CIRCLE = 2,
    PPFS_BTN_SQUARE = 3,
    PPFS_BTN_TRIANGLE = 4,
    PPFS_BTN_UP = 5,
    PPFS_BTN_DOWN = 6,
    PPFS_BTN_LEFT = 7,
    PPFS_BTN_RIGHT = 8,
    PPFS_BTN_L1 = 9,
    PPFS_BTN_R1 = 10
};

typedef struct
{
    uint32_t type;
    int32_t x, y;
    int32_t code;
} ppfs_event;

typedef struct
{
    uint32_t magic, version;
    uint32_t header_size, total_size;
    uint32_t width, height, stride; /* stride in byte, RGBA8 */
    uint32_t buffer_offset;         /* dall'inizio del blocco */
    uint32_t buffer_size;           /* byte di un buffer */

    /* produttore -> consumatore */
    volatile uint32_t frame_seq;      /* +1 a ogni fotogramma completato */
    volatile uint32_t front;          /* buffer con l'ultimo fotogramma completo */
    volatile uint32_t producer_beat;  /* +1 ogni ~mezzo secondo: il produttore e' vivo */
    volatile uint32_t loading;        /* 1 mentre la pagina si carica */
    char title[256];
    char url[1024];
    char status[256];

    /* consumatore -> produttore */
    volatile uint32_t reading;        /* buffer che il consumatore sta copiando (o 0xFFFFFFFF) */
    volatile uint32_t consumer_beat;
    volatile uint32_t ev_head, ev_tail; /* coda circolare: il consumatore scrive head, il produttore legge tail */
    ppfs_event events[PPFS_EVENTS];
    char cmd_url[1024];
} ppfs_header;

#define PPFS_HEADER_BYTES ((uint32_t)((sizeof(ppfs_header) + 4095u) & ~4095u))

static inline uint32_t ppfs_total_size(uint32_t w, uint32_t h)
{
    return PPFS_HEADER_BYTES + PPFS_BUFFERS * (w * 4u * h);
}
static inline uint8_t *ppfs_buffer(ppfs_header *h, uint32_t i)
{
    return (uint8_t *)h + h->buffer_offset + (size_t)i * h->buffer_size;
}
static inline void ppfs_barrier(void) { __atomic_thread_fence(__ATOMIC_SEQ_CST); }

/* ---- produttore ---- */
static inline void ppfs_init(ppfs_header *h, uint32_t w, uint32_t h_px)
{
    uint8_t *p = (uint8_t *)h;
    for (uint32_t i = 0; i < PPFS_HEADER_BYTES; i++)
        p[i] = 0;
    h->magic = PPFS_MAGIC;
    h->version = PPFS_VERSION;
    h->header_size = PPFS_HEADER_BYTES;
    h->total_size = ppfs_total_size(w, h_px);
    h->width = w;
    h->height = h_px;
    h->stride = w * 4u;
    h->buffer_offset = PPFS_HEADER_BYTES;
    h->buffer_size = w * 4u * h_px;
    h->front = 0;
    h->reading = 0xFFFFFFFFu;
    ppfs_barrier();
}
/* buffer libero per il prossimo fotogramma: ne' quello mostrato ne' quello in lettura */
static inline uint32_t ppfs_back(ppfs_header *h)
{
    const uint32_t f = h->front, r = h->reading;
    for (uint32_t i = 0; i < PPFS_BUFFERS; i++)
        if (i != f && i != r)
            return i;
    return (f + 1u) % PPFS_BUFFERS;
}
static inline void ppfs_publish(ppfs_header *h, uint32_t back)
{
    ppfs_barrier();
    h->front = back;
    ppfs_barrier();
    h->frame_seq = h->frame_seq + 1u;
}
static inline int ppfs_pop_event(ppfs_header *h, ppfs_event *out)
{
    if (h->ev_tail == h->ev_head)
        return 0;
    ppfs_barrier();
    *out = h->events[h->ev_tail % PPFS_EVENTS];
    ppfs_barrier();
    h->ev_tail = h->ev_tail + 1u;
    return 1;
}

/* ---- consumatore ---- */
static inline int ppfs_valid(const ppfs_header *h)
{
    return h && h->magic == PPFS_MAGIC && h->version == PPFS_VERSION && h->width && h->height &&
           h->width <= PPFS_MAX_W && h->height <= PPFS_MAX_H && h->stride == h->width * 4u &&
           h->buffer_offset >= sizeof(ppfs_header);
}
static inline int ppfs_push_event(ppfs_header *h, uint32_t type, int32_t x, int32_t y, int32_t code)
{
    if (h->ev_head - h->ev_tail >= PPFS_EVENTS)
        return 0; /* coda piena: il produttore e' fermo */
    ppfs_event *e = &h->events[h->ev_head % PPFS_EVENTS];
    e->type = type;
    e->x = x;
    e->y = y;
    e->code = code;
    ppfs_barrier();
    h->ev_head = h->ev_head + 1u;
    return 1;
}

/* ---- apertura del blocco ----
 * v2 (PS Play v7.66): memoria condivisa POSIX con nome (shm_open), che non passa da nessun
 * filesystem. La v1 usava un file in /data mappato MAP_SHARED e scritto 60 volte al secondo:
 * la console si e' spenta subito dopo l'avvio del produttore dimostrativo, e il filesystem di
 * /data sulla PS5 ha gia' mostrato di non supportare operazioni normali su FreeBSD (socket
 * locali: EOPNOTSUPP). I file "file:" non si aprono piu'. */
#include <fcntl.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

/* produttore: crea il blocco e scrive il localizzatore (un file di testo piccolissimo) */
static inline ppfs_header *ppfs_create(uint32_t w, uint32_t h_px)
{
    const uint32_t total = ppfs_total_size(w, h_px);
    mkdir(PPFS_DIR, 0777);
    shm_unlink(PPFS_SHM_NAME); /* un blocco rimasto da un produttore precedente */
    const int fd = shm_open(PPFS_SHM_NAME, O_RDWR | O_CREAT | O_EXCL, 0666);
    if (fd < 0)
        return NULL;
    if (ftruncate(fd, (off_t)total) != 0)
    {
        close(fd);
        shm_unlink(PPFS_SHM_NAME);
        return NULL;
    }
    void *m = mmap(NULL, total, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    close(fd);
    if (m == MAP_FAILED)
    {
        shm_unlink(PPFS_SHM_NAME);
        return NULL;
    }
    ppfs_header *h = (ppfs_header *)m;
    ppfs_init(h, w, h_px);
    const int lf = open(PPFS_LOCATOR, O_WRONLY | O_CREAT | O_TRUNC, 0666);
    if (lf >= 0)
    {
        const char *loc = "shm:" PPFS_SHM_NAME "\n";
        (void)!write(lf, loc, strlen(loc));
        close(lf);
    }
    return h;
}
/* produttore: chiusura (il consumatore si stacca vedendo il battito a zero) */
static inline void ppfs_destroy(ppfs_header *h)
{
    if (!h)
        return;
    const size_t total = h->total_size;
    unlink(PPFS_LOCATOR);
    shm_unlink(PPFS_SHM_NAME);
    munmap(h, total);
}

/* consumatore: apre il blocco esistente (NULL se non c'e' o non e' valido) */
static inline ppfs_header *ppfs_open(size_t *size_out)
{
    char loc[512] = {0};
    const int lf = open(PPFS_LOCATOR, O_RDONLY);
    if (lf < 0)
        return NULL;
    const ssize_t n = read(lf, loc, sizeof(loc) - 1);
    close(lf);
    if (n <= 4 || strncmp(loc, "shm:", 4) != 0)
        return NULL; /* "file:" della v1: non si apre piu' */
    char *name = loc + 4;
    name[strcspn(name, "\r\n")] = 0;
    const int fd = shm_open(name, O_RDWR, 0666);
    if (fd < 0)
        return NULL;
    struct stat st;
    if (fstat(fd, &st) != 0 || (size_t)st.st_size < PPFS_HEADER_BYTES)
    {
        close(fd);
        return NULL;
    }
    void *m = mmap(NULL, (size_t)st.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    close(fd);
    if (m == MAP_FAILED)
        return NULL;
    ppfs_header *h = (ppfs_header *)m;
    if (!ppfs_valid(h) || h->total_size > (uint32_t)st.st_size)
    {
        munmap(m, (size_t)st.st_size);
        return NULL;
    }
    *size_out = (size_t)st.st_size;
    return h;
}

#endif
