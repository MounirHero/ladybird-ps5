// Ladybird su PS5 - prova della fase 1: se questo file viene eseguito, LibJS funziona.
console.log("Ladybird LibJS sulla PS5");
console.log("data:", new Date().toISOString());
const fib = n => (n < 2 ? n : fib(n - 1) + fib(n - 2));
const t0 = Date.now();
console.log("fib(25) =", fib(25), "in", Date.now() - t0, "ms");
console.log("Intl:", new Intl.NumberFormat("it-IT").format(1234567.891));
console.log("BigInt:", (2n ** 100n).toString());
console.log("JSON:", JSON.stringify({ ok: true, lista: [1, 2, 3] }));
class Punto { #x; constructor(x) { this.#x = x; } get x() { return this.#x; } }
console.log("classi con campi privati:", new Punto(42).x);
console.log("fine della prova");
