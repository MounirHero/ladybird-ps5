/* PS Play - Ladybird fase 3: payload PADRE della prova IPC.
 *
 * Simula quello che dovra' fare Ladybird sulla PS5 per avviare un suo servizio:
 *  1. apre un socket locale in ascolto in /data e scrive il "biglietto" con il percorso
 *  2. lancia il figlio come payload tramite elfldr (il figlio e' incorporato in questo file)
 *  3. accetta la connessione del figlio
 *  4. prova i metodi di memoria condivisa passando il descrittore con SCM_RIGHTS: ognuno dei due
 *     scrive meta' blocco e verifica la meta' dell'altro (prova che la memoria e' davvero comune)
 *  5. prova il verso opposto (figlio -> padre) e la velocita' del socket
 * Risultati in /data/ps_play/logs/lbipc.log (padre) e lbipc_child.log (figlio). */
#include "lbipc_common.h"
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/wait.h>

#ifndef LBIPC_PC
#include "lbipc_child_elf.h" /* generato dalla build: lbipc_child_elf[], lbipc_child_elf_len */
/* invia il figlio a elfldr, con scadenza totale: elfldr potrebbe non accettarlo */
static int launch_child(char *why, size_t wlen)
{
    const int s = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in a;
    memset(&a, 0, sizeof(a));
    a.sin_family = AF_INET;
    a.sin_port = htons(9021);
    a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    fcntl(s, F_SETFL, fcntl(s, F_GETFL, 0) | O_NONBLOCK);
    if (connect(s, (struct sockaddr *)&a, sizeof(a)) != 0 && errno != EINPROGRESS)
    {
        snprintf(why, wlen, "elfldr non raggiungibile (errno %d)", errno);
        close(s);
        return -1;
    }
    if (!wait_fd(s, POLLOUT, 3000))
    {
        snprintf(why, wlen, "elfldr non accetta la connessione entro 3 s");
        close(s);
        return -1;
    }
    size_t off = 0;
    const long t0 = now_ms();
    while (off < lbipc_child_elf_len)
    {
        if (now_ms() - t0 > 10000)
        {
            snprintf(why, wlen, "elfldr non legge il payload (inviati %zu di %u byte in 10 s)", off,
                     (unsigned)lbipc_child_elf_len);
            close(s);
            return -1;
        }
        if (!wait_fd(s, POLLOUT, 500))
            continue;
        const ssize_t n = send(s, lbipc_child_elf + off, lbipc_child_elf_len - off, 0);
        if (n > 0)
            off += (size_t)n;
        else if (n < 0 && errno != EAGAIN && errno != EINTR)
        {
            snprintf(why, wlen, "invio interrotto (errno %d)", errno);
            close(s);
            return -1;
        }
    }
    shutdown(s, SHUT_WR);
    close(s);
    return 0;
}
#else
/* sul PC: il figlio si avvia con fork+exec, senza ereditare il socket (come con elfldr) */
static int launch_child(char *why, size_t wlen)
{
    const pid_t p = fork();
    if (p == 0)
    {
        execl("./lbipc_child", "lbipc_child", (char *)NULL);
        _exit(127);
    }
    if (p < 0)
        snprintf(why, wlen, "fork fallita");
    return p > 0 ? 0 : -1;
}
#endif

/* socket locale in ascolto in una cartella; -1 con il codice d'errore */
static int try_unix(const char *dir, char *path, size_t plen, int *err)
{
    snprintf(path, plen, "%s/lbipc_%d.sock", dir, (int)getpid());
    unlink(path);
    const int s = socket(AF_UNIX, SOCK_STREAM, 0);
    if (s < 0)
    {
        *err = errno;
        return -1;
    }
    struct sockaddr_un a;
    memset(&a, 0, sizeof(a));
    a.sun_family = AF_UNIX;
    snprintf(a.sun_path, sizeof(a.sun_path), "%.100s", path);
    if (bind(s, (struct sockaddr *)&a, sizeof(a)) != 0 || listen(s, 4) != 0)
    {
        *err = errno;
        close(s);
        return -1;
    }
    return s;
}

int main(void)
{
    g_logpath = LBIPC_LOGDIR "/lbipc.log";
    mkdir(LBIPC_LOGDIR, 0777);
    mkdir(LBIPC_DIR, 0777);
    mkdir(LBIPC_DIR "/ipc", 0777);
    unlink(g_logpath);
    lg("==== Ladybird fase 3: prova IPC fra due payload, v3 (padre pid %d) ====", (int)getpid());

    /* 1) socket locale: in quale cartella si puo'? */
    static const char *const dirs[] = {LBIPC_DIR "/ipc", "/tmp", "/system_tmp", "/user/temp", "/data", "/user/data"};
    char sockpath[200] = "", ticket[220] = "";
    int ls = -1, use_unix = 0;
#ifdef LBIPC_FORCE_TCP /* solo per le prove sul PC: simula la PS5 senza socket locali */
    for (unsigned i = sizeof(dirs) / sizeof(dirs[0]); i < sizeof(dirs) / sizeof(dirs[0]); i++)
#else
    for (unsigned i = 0; i < sizeof(dirs) / sizeof(dirs[0]); i++)
#endif
    {
        int err = 0;
        char path[200];
        const int s = try_unix(dirs[i], path, sizeof(path), &err);
        if (s >= 0)
        {
            lg("1) socket locale in %s: OK", dirs[i]);
            if (ls < 0)
            {
                ls = s;
                use_unix = 1;
                snprintf(sockpath, sizeof(sockpath), "%s", path);
            }
            else
            {
                close(s);
                unlink(path);
            }
        }
        else
            lg("1) socket locale in %s: no (errno %d %s)", dirs[i], err, errname(err));
    }
    if (use_unix)
        snprintf(ticket, sizeof(ticket), "unix:%s", sockpath);
    else
    {
        /* 1b) ripiego: TCP su 127.0.0.1, porta scelta dal sistema */
        ls = socket(AF_INET, SOCK_STREAM, 0);
        struct sockaddr_in a;
        memset(&a, 0, sizeof(a));
        a.sin_family = AF_INET;
        a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
        socklen_t al = sizeof(a);
        if (ls < 0 || bind(ls, (struct sockaddr *)&a, sizeof(a)) != 0 || listen(ls, 4) != 0 ||
            getsockname(ls, (struct sockaddr *)&a, &al) != 0)
        {
            lg("1b) TCP su 127.0.0.1: FALLITO (errno %d %s)", errno, errname(errno));
            lg("RISULTATO C: nessun canale fra processi: i servizi di Ladybird andranno eseguiti come thread");
            return 1;
        }
        snprintf(ticket, sizeof(ticket), "tcp:%d", (int)ntohs(a.sin_port));
        lg("1b) nessun socket locale: uso TCP su 127.0.0.1:%d", (int)ntohs(a.sin_port));
    }
    const int tf = open(LBIPC_TICKET, O_WRONLY | O_CREAT | O_TRUNC, 0666);
    if (tf >= 0)
    {
        (void)!write(tf, ticket, strlen(ticket));
        (void)!write(tf, "\n", 1);
        close(tf);
    }

    /* 2) secondo payload tramite elfldr */
    char why[200] = "";
    const long t_launch = now_ms();
    if (launch_child(why, sizeof(why)) != 0)
    {
        lg("2) avvio del figlio tramite elfldr: FALLITO - %s", why);
        lg("RISULTATO C: elfldr non avvia un secondo payload mentre il primo e' in esecuzione: thread");
        return 1;
    }
    lg("2) figlio inviato a elfldr in %ld ms", now_ms() - t_launch);
    if (!wait_fd(ls, POLLIN, 15000))
    {
        lg("3) il figlio non si e' collegato entro 15 s (vedi la parte del figlio qui sotto)");
        lg("RISULTATO: elfldr ha accettato il figlio, ma il collegamento non e' avvenuto");
        return 1;
    }
    const int s = accept(ls, NULL, NULL);
    char msg[300];
    int fd = -1;
    if (s < 0 || recv_msg(s, msg, sizeof(msg), &fd, 5000) != 0)
    {
        lg("3) connessione del figlio: FALLITA (errno %d %s)", errno, errname(errno));
        return 1;
    }
    lg("3) figlio collegato via %s in %ld ms: \"%s\"", use_unix ? "socket locale" : "TCP", now_ms() - t_launch, msg);

    /* 4) memoria condivisa: con il socket locale si passano i descrittori, con TCP i nomi */
    int ok_fd[MEM_COUNT] = {0}, ok_name[MEM_COUNT] = {0};
    for (int m = 0; m < MEM_COUNT; m++)
    {
        const int seed = 10 + m;
        if (m == MEM_FILE)
        {
            /* v7.66: un file in /data mappato in condivisione e' il primo sospettato dello
             * spegnimento della console (produttore dimostrativo v1): non si prova piu' */
            lg("4) %s: saltato (sospettato di spegnere la console)", mem_name(m));
            continue;
        }
        if (use_unix)
        {
            char w[120] = "";
            const int mfd = mem_create(m, w, sizeof(w));
            uint8_t *p = mfd >= 0 ? mem_map(mfd) : NULL;
            if (!p)
            {
                lg("4) %s per descrittore: non disponibile - %s", mem_name(m), mfd < 0 ? w : "mmap fallita");
                if (mfd >= 0)
                    close(mfd);
                continue;
            }
            fill_half(p, 0, seed);
            char out[64];
            snprintf(out, sizeof(out), "MEM %d %d", m, seed);
            send_msg(s, out, mfd);
            close(mfd);
            int rfd = -1, mm = -1, ok_a = 0;
            if (recv_msg(s, msg, sizeof(msg), &rfd, 10000) == 0 && sscanf(msg, "OK %d %d", &mm, &ok_a) == 2)
            {
                ok_fd[m] = ok_a && check_half(p, 1, seed);
                lg("4) %s per descrittore: %s", mem_name(m), ok_fd[m] ? "FUNZIONA" : "NON CONDIVISA");
            }
            else
                lg("4) %s per descrittore: %s", mem_name(m), msg);
            munmap(p, LBIPC_MEM);
        }
        if (m == MEM_SHM_ANON)
            continue; /* SHM_ANON non ha nome */
        char name[200] = "", w[120] = "";
        const int nfd = mem_create_named(m, name, sizeof(name), w, sizeof(w));
        uint8_t *p = nfd >= 0 ? mem_map(nfd) : NULL;
        if (!p)
        {
            lg("4) %s per nome: non disponibile - %s", mem_name(m), nfd < 0 ? w : "mmap fallita");
            if (nfd >= 0)
            {
                close(nfd);
                mem_unlink_named(m, name);
            }
            continue;
        }
        fill_half(p, 0, seed);
        char out[260];
        snprintf(out, sizeof(out), "MEMNAME %d %d %s", m, seed, name);
        send_msg(s, out, -1);
        int rfd = -1, mm = -1, ok_a = 0;
        if (recv_msg(s, msg, sizeof(msg), &rfd, 10000) == 0 && sscanf(msg, "OK %d %d", &mm, &ok_a) == 2)
        {
            ok_name[m] = ok_a && check_half(p, 1, seed);
            lg("4) %s per nome: %s", mem_name(m), ok_name[m] ? "FUNZIONA" : "NON CONDIVISA");
        }
        else
            lg("4) %s per nome: %s", mem_name(m), msg);
        munmap(p, LBIPC_MEM);
        close(nfd);
        mem_unlink_named(m, name);
    }

    /* 5) verso opposto */
    if (use_unix)
    {
        send_msg(s, "GIVE", -1);
        if (recv_msg(s, msg, sizeof(msg), &fd, 10000) == 0 && fd >= 0)
        {
            uint8_t *p = mem_map(fd);
            lg("5) figlio -> padre per descrittore: %s", p && check_half(p, 0, 77) ? "FUNZIONA" : "FALLITO");
            if (p)
                munmap(p, LBIPC_MEM);
            close(fd);
        }
    }
    send_msg(s, "GIVENAME", -1);
    if (recv_msg(s, msg, sizeof(msg), &fd, 10000) == 0)
    {
        char name[200] = "";
        if (sscanf(msg, "TAKENAME %199s", name) == 1 && name[0] == '/')
        {
            const int nfd = mem_open_named(MEM_SHM_NAMED, name);
            uint8_t *p = nfd >= 0 ? mem_map(nfd) : NULL;
            lg("5) figlio -> padre per nome: %s", p && check_half(p, 0, 77) ? "FUNZIONA" : "FALLITO");
            if (p)
                munmap(p, LBIPC_MEM);
            if (nfd >= 0)
                close(nfd);
            mem_unlink_named(MEM_SHM_NAMED, name);
        }
        else
            lg("5) figlio -> padre per nome: %s", msg);
    }

    /* 6) velocita' */
    const long bulk = 32L << 20;
    char out[64];
    snprintf(out, sizeof(out), "BULK %ld", bulk);
    send_msg(s, out, -1);
    if (recv_msg(s, msg, sizeof(msg), &fd, 5000) != 0 || strcmp(msg, "READY") != 0)
        lg("6) il figlio non ha confermato il trasferimento (%s)", msg);
    static char buf[65536];
    memset(buf, 0x5A, sizeof(buf));
    const long t0 = now_ms();
    long sent = 0;
    while (sent < bulk && wait_fd(s, POLLOUT, 5000))
    {
        const ssize_t n = send(s, buf, (size_t)(bulk - sent < (long)sizeof(buf) ? bulk - sent : (long)sizeof(buf)), 0);
        if (n <= 0)
            break;
        sent += n;
    }
    if (recv_msg(s, msg, sizeof(msg), &fd, 15000) == 0)
    {
        const long ms = now_ms() - t0;
        lg("6) velocita': %ld MB in %ld ms (%.0f MB/s) - %s", sent >> 20, ms,
           ms > 0 ? (double)(sent >> 20) * 1000.0 / (double)ms : 0.0, msg);
    }
    send_msg(s, "BYE", -1);
    close(s);
    close(ls);
    if (use_unix)
        unlink(sockpath);

    int any_fd = 0, any_name = 0;
    for (int m = 0; m < MEM_COUNT; m++)
    {
        any_fd |= ok_fd[m];
        any_name |= ok_name[m];
    }
    if (use_unix && any_fd)
        lg("RISULTATO A: processi separati con socket locale e descrittori: l'IPC di Ladybird funziona "
           "cosi' com'e' (cambiano solo l'avvio dei servizi e la cartella dei socket)%s",
           ok_fd[MEM_SHM_ANON] ? ", memoria con SHM_ANON" : "");
    else if (any_name)
        lg("RISULTATO B: processi separati possibili, ma senza passaggio di descrittori: il trasporto di "
           "Ladybird va adattato (TCP locale e memoria condivisa passata per nome)");
    else
        lg("RISULTATO C: la memoria non si condivide fra payload: i servizi di Ladybird andranno eseguiti come thread");
#ifdef LBIPC_PC
    wait(NULL);
#endif
    return 0;
}
