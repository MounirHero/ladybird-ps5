/* PS Play - Ladybird fase 3, prova di fattibilita' dell'IPC fra due payload.
 * Parti comuni a padre e figlio: log, passaggio di descrittori (SCM_RIGHTS), memoria condivisa
 * con i metodi che Ladybird potrebbe usare, verifica dei contenuti. */
#ifndef LBIPC_COMMON_H
#define LBIPC_COMMON_H

#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <time.h>
#include <unistd.h>

#ifndef LBIPC_DIR
#define LBIPC_DIR "/data/ps_play/ladybird"
#endif
#ifndef LBIPC_LOGDIR
#define LBIPC_LOGDIR "/data/ps_play/logs"
#endif
#define LBIPC_TICKET LBIPC_DIR "/ipc/ticket.txt"
#define LBIPC_MEM (1u << 20) /* 1 MB per blocco */

static const char *g_logpath;
static void lg(const char *fmt, ...)
{
    char b[600];
    va_list a;
    va_start(a, fmt);
    int n = vsnprintf(b, sizeof(b) - 1, fmt, a);
    va_end(a);
    if (n < 0)
        return;
    if (n > (int)sizeof(b) - 2)
        n = (int)sizeof(b) - 2;
    b[n++] = '\n';
    const int fd = open(g_logpath, O_WRONLY | O_CREAT | O_APPEND, 0666);
    if (fd >= 0)
    {
        (void)!write(fd, b, (size_t)n);
        fsync(fd); /* v7.66: dopo un crash del sistema l'ultima riga deve esserci */
        close(fd);
    }
}
static const char *errname(int e)
{
    switch (e)
    {
    case 1: return "EPERM";
    case 2: return "ENOENT";
    case 13: return "EACCES";
    case 22: return "EINVAL";
    case 30: return "EROFS";
    case 43: return "EPROTONOSUPPORT";
    case 45: return "EOPNOTSUPP";
    case 47: return "EAFNOSUPPORT";
    case 48: return "EADDRINUSE";
    case 61: return "ECONNREFUSED";
    case 63: return "ENAMETOOLONG";
    case 78: return "ENOSYS";
    default: return "?";
    }
}
static long now_ms(void)
{
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec * 1000L + t.tv_nsec / 1000000L;
}
static int wait_fd(int fd, short ev, int ms)
{
    struct pollfd p = {fd, ev, 0};
    return poll(&p, 1, ms) > 0 && (p.revents & ev);
}

/* messaggio di testo con al massimo un descrittore allegato */
static int send_msg(int sock, const char *text, int fd)
{
    struct iovec iov = {(void *)text, strlen(text) + 1};
    struct msghdr m;
    memset(&m, 0, sizeof(m));
    m.msg_iov = &iov;
    m.msg_iovlen = 1;
    char cbuf[CMSG_SPACE(sizeof(int))];
    if (fd >= 0)
    {
        memset(cbuf, 0, sizeof(cbuf));
        m.msg_control = cbuf;
        m.msg_controllen = sizeof(cbuf);
        struct cmsghdr *c = CMSG_FIRSTHDR(&m);
        c->cmsg_level = SOL_SOCKET;
        c->cmsg_type = SCM_RIGHTS;
        c->cmsg_len = CMSG_LEN(sizeof(int));
        memcpy(CMSG_DATA(c), &fd, sizeof(int));
    }
    return sendmsg(sock, &m, 0) >= 0 ? 0 : -1;
}
/* riceve un messaggio (entro ms); *fd_out = descrittore allegato o -1 */
static int recv_msg(int sock, char *text, size_t cap, int *fd_out, int ms)
{
    *fd_out = -1;
    if (!wait_fd(sock, POLLIN, ms))
        return -1;
    struct iovec iov = {text, cap - 1};
    struct msghdr m;
    memset(&m, 0, sizeof(m));
    m.msg_iov = &iov;
    m.msg_iovlen = 1;
    char cbuf[CMSG_SPACE(sizeof(int)) + 64];
    m.msg_control = cbuf;
    m.msg_controllen = sizeof(cbuf);
    const ssize_t n = recvmsg(sock, &m, 0);
    if (n <= 0)
        return -1;
    text[n] = 0;
    for (struct cmsghdr *c = CMSG_FIRSTHDR(&m); c; c = CMSG_NXTHDR(&m, c))
        if (c->cmsg_level == SOL_SOCKET && c->cmsg_type == SCM_RIGHTS)
            memcpy(fd_out, CMSG_DATA(c), sizeof(int));
    return 0;
}

/* memoria condivisa: i metodi in ordine di somiglianza con Ladybird */
enum
{
    MEM_SHM_ANON = 0, /* shm_open(SHM_ANON): il ramo BSD di Core::System::anon_create */
    MEM_SHM_NAMED,    /* shm_open con nome + shm_unlink */
    MEM_FILE,         /* file in /data subito cancellato: ripiego sempre possibile */
    MEM_COUNT
};
static const char *mem_name(int m)
{
    return m == MEM_SHM_ANON ? "shm_open(SHM_ANON)" : m == MEM_SHM_NAMED ? "shm_open(nome)" : "file in /data";
}
static int mem_create(int m, char *why, size_t wlen)
{
    int fd = -1;
    if (m == MEM_SHM_ANON)
    {
#ifdef SHM_ANON
        fd = shm_open(SHM_ANON, O_RDWR | O_CREAT, 0600);
#else
        snprintf(why, wlen, "SHM_ANON non definito su questa piattaforma");
        return -1;
#endif
    }
    else if (m == MEM_SHM_NAMED)
    {
        char name[64];
        snprintf(name, sizeof(name), "/lbipc_%d_%ld", (int)getpid(), now_ms());
        fd = shm_open(name, O_RDWR | O_CREAT | O_EXCL, 0600);
        if (fd >= 0)
            shm_unlink(name);
    }
    else
    {
        char path[160];
        snprintf(path, sizeof(path), LBIPC_DIR "/ipc/mem_%d_%ld", (int)getpid(), now_ms());
        fd = open(path, O_RDWR | O_CREAT | O_EXCL, 0600);
        if (fd >= 0)
            unlink(path);
    }
    if (fd < 0)
    {
        snprintf(why, wlen, "creazione fallita (errno %d %s)", errno, errname(errno));
        return -1;
    }
    if (ftruncate(fd, LBIPC_MEM) != 0)
    {
        snprintf(why, wlen, "ftruncate fallita (errno %d)", errno);
        close(fd);
        return -1;
    }
    return fd;
}
/* per nome: il padre crea senza cancellare, il figlio apre con lo stesso nome */
static int mem_create_named(int m, char *name, size_t nlen, char *why, size_t wlen)
{
    int fd = -1;
    if (m == MEM_SHM_NAMED)
    {
        snprintf(name, nlen, "/lbipc_%d_%ld", (int)getpid(), now_ms());
        fd = shm_open(name, O_RDWR | O_CREAT | O_EXCL, 0666);
    }
    else if (m == MEM_FILE)
    {
        snprintf(name, nlen, LBIPC_DIR "/ipc/mem_%d_%ld", (int)getpid(), now_ms());
        fd = open(name, O_RDWR | O_CREAT | O_EXCL, 0666);
    }
    else
    {
        snprintf(why, wlen, "non si passa per nome");
        return -1;
    }
    if (fd < 0)
    {
        snprintf(why, wlen, "creazione fallita (errno %d %s)", errno, errname(errno));
        return -1;
    }
    if (ftruncate(fd, LBIPC_MEM) != 0)
    {
        snprintf(why, wlen, "ftruncate fallita (errno %d %s)", errno, errname(errno));
        close(fd);
        return -1;
    }
    return fd;
}
static int mem_open_named(int m, const char *name)
{
    return m == MEM_SHM_NAMED ? shm_open(name, O_RDWR, 0666) : open(name, O_RDWR);
}
__attribute__((unused)) static void mem_unlink_named(int m, const char *name)
{
    if (m == MEM_SHM_NAMED)
        shm_unlink(name);
    else
        unlink(name);
}
static uint8_t *mem_map(int fd)
{
    void *p = mmap(NULL, LBIPC_MEM, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    return p == MAP_FAILED ? NULL : (uint8_t *)p;
}
/* meta' A la scrive il padre, meta' B il figlio: ognuno verifica quella dell'altro */
static void fill_half(uint8_t *p, int half, int seed)
{
    uint8_t *q = p + (half ? LBIPC_MEM / 2 : 0);
    for (uint32_t i = 0; i < LBIPC_MEM / 2; i++)
        q[i] = (uint8_t)((i * 31u + (uint32_t)seed * 7u + (uint32_t)half * 101u) & 0xFF);
}
static int check_half(const uint8_t *p, int half, int seed)
{
    const uint8_t *q = p + (half ? LBIPC_MEM / 2 : 0);
    for (uint32_t i = 0; i < LBIPC_MEM / 2; i++)
        if (q[i] != (uint8_t)((i * 31u + (uint32_t)seed * 7u + (uint32_t)half * 101u) & 0xFF))
            return 0;
    return 1;
}

#endif
