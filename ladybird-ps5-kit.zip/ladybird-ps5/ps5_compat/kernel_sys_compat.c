/* PS Play Native GL v7.39 - funzioni POSIX che l'SDK dichiara SOLO in libkernel_sys.
 *
 * Nel processo di un'app (PPSA) libkernel_sys non e' disponibile: un import da li' resta a 0 e
 * la chiamata salta all'indirizzo zero (crash). Era il crash del torrent all'avvio della
 * sessione: libtransmission chiama umask() subito dopo il passo "statistiche".
 * Definendole qui il linker non le importa piu': ognuna e' implementata con le funzioni di
 * libkernel (open, stat, lstat, unlink, rmdir, chmod, utimes) o fallisce in modo pulito.
 */
#include <errno.h>
#include <fcntl.h>
#include <stdarg.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>

#ifndef AT_FDCWD
#define AT_FDCWD -100
#endif
#ifndef AT_SYMLINK_NOFOLLOW
#define AT_SYMLINK_NOFOLLOW 0x200
#endif
#ifndef AT_REMOVEDIR
#define AT_REMOVEDIR 0x800
#endif

static mode_t g_umask = 022;

/* percorso utilizzabile senza la directory dfd: assoluto, oppure relativo alla cartella corrente */
static int pp_at_ok(int dfd, const char *path)
{
    if (!path) { errno = EFAULT; return 0; }
    if (path[0] == '/' || dfd == AT_FDCWD) return 1;
    errno = ENOSYS;
    return 0;
}

mode_t umask(mode_t m) { mode_t old = g_umask; g_umask = m & 0777; return old; }
pid_t fork(void) { errno = ENOSYS; return -1; }
int fchdir(int fd) { (void)fd; errno = ENOSYS; return -1; }
int fchown(int fd, uid_t u, gid_t g) { (void)fd; (void)u; (void)g; return 0; }
int lchown(const char *p, uid_t u, gid_t g) { (void)u; (void)g; return p ? 0 : (errno = EFAULT, -1); }
int lchmod(const char *p, mode_t m) { return chmod(p, m); }
int lchflags(const char *p, unsigned long f) { (void)f; return p ? 0 : (errno = EFAULT, -1); }
int symlink(const char *a, const char *b) { (void)a; (void)b; errno = ENOSYS; return -1; }
int linkat(int fd1, const char *p1, int fd2, const char *p2, int fl)
{ (void)fd1; (void)p1; (void)fd2; (void)p2; (void)fl; errno = ENOSYS; return -1; }
int lutimes(const char *p, const struct timeval tv[2]) { return utimes(p, tv); }
int futimesat(int dfd, const char *p, const struct timeval tv[2])
{
    return pp_at_ok(dfd, p) ? utimes(p, tv) : -1;
}
int fstatat(int dfd, const char *p, struct stat *st, int fl)
{
    if (!pp_at_ok(dfd, p)) return -1;
    return (fl & AT_SYMLINK_NOFOLLOW) ? lstat(p, st) : stat(p, st);
}
int unlinkat(int dfd, const char *p, int fl)
{
    if (!pp_at_ok(dfd, p)) return -1;
    return (fl & AT_REMOVEDIR) ? rmdir(p) : unlink(p);
}
int openat(int dfd, const char *p, int fl, ...)
{
    int mode = 0;
    if (fl & O_CREAT) { va_list ap; va_start(ap, fl); mode = va_arg(ap, int); va_end(ap); }
    if (!pp_at_ok(dfd, p)) return -1;
    return open(p, fl, mode & ~(int)g_umask);
}
