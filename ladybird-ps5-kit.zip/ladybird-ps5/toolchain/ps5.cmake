# Toolchain CMake per la PS5 (ps5-payload-sdk). La PS5 deriva da FreeBSD: l'SDK definisce
# __FreeBSD__, quindi Ladybird usa i suoi percorsi FreeBSD (AK_OS_FREEBSD).
# Richiede PS5_PAYLOAD_SDK nell'ambiente e un clang >= 19 (Ladybird non accetta il 18):
# l'SDK chiama "$PS5_PAYLOAD_SDK/bin/clang", quindi basta che punti a clang-21.
set(CMAKE_SYSTEM_NAME FreeBSD)
set(CMAKE_SYSTEM_PROCESSOR x86_64)
if (NOT DEFINED ENV{PS5_PAYLOAD_SDK})
    message(FATAL_ERROR "PS5_PAYLOAD_SDK non impostata")
endif()
set(PS5_PAYLOAD_SDK "$ENV{PS5_PAYLOAD_SDK}")
set(CMAKE_C_COMPILER "${PS5_PAYLOAD_SDK}/bin/prospero-clang")
set(CMAKE_CXX_COMPILER "${PS5_PAYLOAD_SDK}/bin/prospero-clang++")
foreach(t ar ranlib nm strip objcopy)
    string(TOUPPER ${t} T)
    if (EXISTS "${PS5_PAYLOAD_SDK}/bin/prospero-${t}")
        set(CMAKE_${T} "${PS5_PAYLOAD_SDK}/bin/prospero-${t}")
    endif()
endforeach()
# le prove di compilazione di CMake non devono collegare un eseguibile PS5 completo
set(CMAKE_TRY_COMPILE_TARGET_TYPE STATIC_LIBRARY)
list(APPEND CMAKE_FIND_ROOT_PATH "${PS5_PAYLOAD_SDK}/target")
set(CMAKE_FIND_ROOT_PATH_MODE_PROGRAM NEVER)
set(CMAKE_FIND_ROOT_PATH_MODE_LIBRARY ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_INCLUDE ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_PACKAGE ONLY)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)
