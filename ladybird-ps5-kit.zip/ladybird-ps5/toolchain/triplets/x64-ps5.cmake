# Triplet vcpkg per la PS5: librerie statiche, compilate con il toolchain dell'SDK.
set(VCPKG_TARGET_ARCHITECTURE x64)
set(VCPKG_CRT_LINKAGE dynamic)
set(VCPKG_LIBRARY_LINKAGE static)
set(VCPKG_CMAKE_SYSTEM_NAME FreeBSD)
set(VCPKG_BUILD_TYPE release)
set(VCPKG_CHAINLOAD_TOOLCHAIN_FILE "${CMAKE_CURRENT_LIST_DIR}/../ps5.cmake")
set(VCPKG_ENV_PASSTHROUGH PS5_PAYLOAD_SDK)
