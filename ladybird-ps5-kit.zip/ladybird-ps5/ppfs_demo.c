/* PS Play - produttore dimostrativo di fotogrammi (fase 4 del browser Ladybird).
 *
 * Fa la parte che domani fara' il frontend PS5 di Ladybird: disegna una "pagina" in memoria
 * condivisa e reagisce all'input che arriva da PS Play. Serve a provare sulla console il
 * trasporto dei fotogrammi e dell'input PRIMA che il browser esista:
 *  - 9 riquadri come "link"; il cursore (levetta sinistra / croce direzionale in PS Play) li
 *    evidenzia e Croce li "apre" (cambiano colore e il titolo dice quale)
 *  - una barra che scorre: se si muove, i fotogrammi arrivano
 *  - L1/R1 e scorrimento spostano la pagina in verticale
 *  - un URL inviato da PS Play diventa il titolo; "Esci" chiude il payload
 * Si chiude da solo se PS Play smette di dare segni di vita per 20 secondi.
 */
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include "frameshare.h"

#define W 1280u
#define H 720u

static void fill(uint8_t *px, int x0, int y0, int w, int h, uint32_t rgba)
{
    for (int y = y0; y < y0 + h; y++)
    {
        if (y < 0 || y >= (int)H)
            continue;
        uint32_t *row = (uint32_t *)(px + (size_t)y * W * 4u);
        for (int x = x0; x < x0 + w; x++)
            if (x >= 0 && x < (int)W)
                row[x] = rgba;
    }
}
/* RGBA8 in memoria: byte R,G,B,A -> su little endian il valore e' 0xAABBGGRR */
static uint32_t rgb(uint32_t r, uint32_t g, uint32_t b) { return 0xFF000000u | (b << 16) | (g << 8) | r; }

static void sleep_ms(long ms)
{
    struct timespec ts = {ms / 1000, (ms % 1000) * 1000000L};
    nanosleep(&ts, NULL);
}

int main(void)
{
    ppfs_header *h = ppfs_create(W, H);
    if (!h)
    {
        printf("ppfs_demo: impossibile creare la memoria condivisa %s\n", PPFS_SHM_NAME);
        return 1;
    }
    snprintf(h->title, sizeof(h->title), "Pagina dimostrativa");
    snprintf(h->url, sizeof(h->url), "ppfs://demo");
    snprintf(h->status, sizeof(h->status), "pronto");

    int cx = (int)W / 2, cy = (int)H / 2, scroll = 0, opened = -1;
    uint32_t last_consumer = 0;
    int stale_frames = 0, running = 1;
    for (uint32_t frame = 0; running; frame++)
    {
        ppfs_event e;
        while (ppfs_pop_event(h, &e))
        {
            if (e.type == PPFS_EV_POINTER_MOVE)
            {
                cx = e.x;
                cy = e.y;
            }
            else if (e.type == PPFS_EV_SCROLL)
                scroll += e.y;
            else if (e.type == PPFS_EV_BUTTON_DOWN && e.code == PPFS_BTN_L1)
                scroll -= 120;
            else if (e.type == PPFS_EV_BUTTON_DOWN && e.code == PPFS_BTN_R1)
                scroll += 120;
            else if (e.type == PPFS_EV_BUTTON_DOWN && e.code == PPFS_BTN_CROSS)
            {
                const int col = (cx - 140) / 340, row = (cy + scroll - 150) / 180;
                if (col >= 0 && col < 3 && row >= 0 && row < 3 && (cx - 140) % 340 < 300 &&
                    (cy + scroll - 150) % 180 < 150)
                {
                    opened = row * 3 + col;
                    snprintf(h->title, sizeof(h->title), "Link %d aperto", opened + 1);
                }
            }
            else if (e.type == PPFS_EV_NAVIGATE)
            {
                h->loading = 1;
                snprintf(h->url, sizeof(h->url), "%s", h->cmd_url);
                snprintf(h->title, sizeof(h->title), "Navigazione richiesta");
                snprintf(h->status, sizeof(h->status), "(dimostrativo: nessun motore web)");
                h->loading = 0;
            }
            else if (e.type == PPFS_EV_QUIT)
                running = 0;
        }
        scroll = scroll < 0 ? 0 : (scroll > 400 ? 400 : scroll);

        const uint32_t back = ppfs_back(h);
        uint8_t *px = ppfs_buffer(h, back);
        fill(px, 0, 0, (int)W, (int)H, rgb(18, 22, 34));         /* sfondo */
        fill(px, 0, 0, (int)W, 90, rgb(40, 52, 80));              /* intestazione */
        fill(px, (int)(frame * 6u % W), 84, 160, 6, rgb(90, 200, 255)); /* barra che scorre */
        for (int i = 0; i < 9; i++)
        {
            const int x = 140 + (i % 3) * 340, y = 150 + (i / 3) * 180 - scroll;
            const int hover = cx >= x && cx < x + 300 && cy >= y && cy < y + 150;
            const uint32_t c = i == opened ? rgb(80, 200, 120) : hover ? rgb(90, 140, 230) : rgb(52, 62, 92);
            fill(px, x, y, 300, 150, c);
            fill(px, x + 20, y + 20, 120 + i * 15, 14, rgb(220, 226, 240)); /* "testo" */
            fill(px, x + 20, y + 50, 200, 10, rgb(150, 160, 185));
        }
        fill(px, cx - 2, cy - 14, 4, 28, rgb(255, 255, 255)); /* cursore */
        fill(px, cx - 14, cy - 2, 28, 4, rgb(255, 255, 255));
        ppfs_publish(h, back);

        if (frame % 30u == 0)
        {
            h->producer_beat = h->producer_beat + 1u;
            snprintf(h->status, sizeof(h->status), "fotogramma %u, cursore %d,%d", frame, cx, cy);
            if (h->consumer_beat == last_consumer)
                stale_frames += 30;
            else
                stale_frames = 0;
            last_consumer = h->consumer_beat;
            if (stale_frames > 20 * 30) /* PS Play non risponde da ~20 s */
                running = 0;
        }
        sleep_ms(33); /* v7.66: 30 fotogrammi al secondo */
    }
    snprintf(h->status, sizeof(h->status), "produttore chiuso");
    h->producer_beat = 0;
    sleep_ms(500); /* il consumatore vede il battito a zero e si stacca */
    ppfs_destroy(h);
    return 0;
}
