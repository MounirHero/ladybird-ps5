#!/usr/bin/env bash
# Ladybird per PS5 - fase 1: l'interprete JavaScript "js" come payload PS5.
# Da lanciare sulla macchina di build (Linux). Non testato fuori da questa macchina: il primo
# giro serve proprio a raccogliere gli errori.
set -euo pipefail
: "${PS5_PAYLOAD_SDK:?imposta PS5_PAYLOAD_SDK (cartella del ps5-payload-sdk)}"
: "${LADYBIRD_SRC:?imposta LADYBIRD_SRC (cartella del sorgente di Ladybird)}"
: "${VCPKG_ROOT:?clona https://github.com/microsoft/vcpkg, lancia bootstrap-vcpkg.sh e imposta VCPKG_ROOT}"
KIT="$(cd "$(dirname "$0")" && pwd)"
BUILD="$LADYBIRD_SRC/Build/ps5"

# 1) clang >= 19: l'SDK usa "$PS5_PAYLOAD_SDK/bin/clang"
v=$("$PS5_PAYLOAD_SDK/bin/clang" --version | grep -oE 'version [0-9]+' | grep -oE '[0-9]+' | head -1)
if [ "${v:-0}" -lt 19 ]; then
    echo "Il clang dell'SDK e' la versione $v; Ladybird richiede >= 19. Per esempio:"
    echo "  ln -sf \"\$(command -v clang-21)\" \"$PS5_PAYLOAD_SDK/bin/clang\""
    echo "  ln -sf \"\$(command -v clang-21)\" \"$PS5_PAYLOAD_SDK/bin/clang++\""
    exit 1
fi

# 2) Rust per FreeBSD (la PS5 ne deriva): serve alle parti Rust di LibJS
rustup target add x86_64-unknown-freebsd

# 3) modalita' "solo JavaScript"
python3 "$KIT/apply_ps5_js_only.py" "$LADYBIRD_SRC"

# 4) configurazione: dipendenze compilate per la PS5 da vcpkg, niente JIT, niente interfaccia
cmake -S "$LADYBIRD_SRC" -B "$BUILD" -G Ninja \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_TOOLCHAIN_FILE="$VCPKG_ROOT/scripts/buildsystems/vcpkg.cmake" \
    -DVCPKG_CHAINLOAD_TOOLCHAIN_FILE="$KIT/toolchain/ps5.cmake" \
    -DVCPKG_TARGET_TRIPLET=x64-ps5 \
    -DVCPKG_OVERLAY_TRIPLETS="$KIT/toolchain/triplets" \
    -DVCPKG_HOST_TRIPLET=x64-linux \
    -DLADYBIRD_PS5_JS_ONLY=ON \
    -DBUILD_SHARED_LIBS=OFF \
    -DENABLE_GUI_TARGETS=OFF \
    -DENABLE_JS_JIT=OFF \
    -DENABLE_CRANELIFT_JIT=OFF \
    -DLADYBIRD_ENABLE_CPPTRACE=OFF \
    -DENABLE_CLANG_PLUGINS=OFF \
    -DBUILD_TESTING=OFF \
    -DRUST_TARGET_TRIPLE=x86_64-unknown-freebsd \
    -DLAGOM_LINK_POOL_SIZE=2 \
    2>&1 | tee "$KIT/log_configurazione.txt"

# 5) compilazione del solo js
ninja -C "$BUILD" js 2>&1 | tee "$KIT/log_compilazione.txt"

# 6) controllo dei simboli: quelli che la PS5 non fornisce diventano salti all'indirizzo 0
JS_BIN="$(find "$BUILD" -type f -name js -perm -u+x | head -1)"
"$KIT/check_symbols.sh" "$JS_BIN" | tee "$KIT/log_simboli.txt"
echo
echo "Fatto: $JS_BIN"
echo "Sulla PS5: copia test.js in /data/ps_play/ladybird/, invia js a elfldr (porta 9021),"
echo "poi leggi /data/ps_play/logs/ladybird_js.log"
