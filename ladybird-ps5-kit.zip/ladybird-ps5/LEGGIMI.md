# Ladybird per PS5 — kit della fase 1

Obiettivo della fase 1: **l'interprete JavaScript di Ladybird (`js`) che gira come payload
sulla PS5**. È il primo mattone del browser: LibJS, il garbage collector, Unicode/ICU e la
crittografia, senza grafica né rete.

## Cosa ho verificato sul sorgente che mi hai mandato
- Ladybird ha già **11 punti specifici per FreeBSD** (AK, LibCore): la PS5 ne deriva e l'SDK
  definisce `__FreeBSD__`, quindi il sorgente segue già quei percorsi.
- Entrambi i JIT sono **disattivabili** (`ENABLE_JS_JIT`, `ENABLE_CRANELIFT_JIT`): sulla PS5
  si parte senza, con l'interprete.
- La parte **Rust** di LibJS è sempre necessaria (1076 file `.rs` nel progetto): si compila per
  `x86_64-unknown-freebsd`.
- Per `js` servono **9 librerie interne su 38** e **8 dipendenze esterne su 47**
  (ICU, OpenSSL, fmt, simdutf, mimalloc, fast_float, libtommath, zlib).
- Ladybird richiede **clang ≥ 19**; il clang dell'SDK che ho qui è il 18. Sulla tua macchina
  basta far puntare `$PS5_PAYLOAD_SDK/bin/clang` a clang-21.
- Il C++23 con le intestazioni della PS5 compila (`std::expected`).

`apply_ps5_js_only.py` è stato **provato sul tuo sorgente**: si applica pulito e si può
rilanciare senza danni. `check_symbols.sh` è stato provato su un binario PS5 vero.
**La build vera non è stata fatta**: qui non ho rete, cmake, Rust né spazio. Il primo giro
serve proprio a raccogliere gli errori.

## Requisiti della macchina di build (Linux)
- 8+ core, 16 GB di RAM, 30 GB liberi (per la fase 1)
- `cmake` ≥ 3.30, `ninja`, `python3`, `git`, `pkg-config`, `nasm`, `autoconf`, `automake`, `libtool`
- clang-21 (o almeno 19), `rustup`
- il **ps5-payload-sdk** (lo stesso di PS Play) e **vcpkg**:
  `git clone https://github.com/microsoft/vcpkg && ./vcpkg/bootstrap-vcpkg.sh`

## Uso
```bash
export PS5_PAYLOAD_SDK=/percorso/ps5-payload-sdk
export LADYBIRD_SRC=/percorso/ladybird
export VCPKG_ROOT=/percorso/vcpkg
./build_fase1_js.sh
```
Lo script controlla il clang, aggiunge il target Rust, applica la modalità "solo JavaScript",
configura con le dipendenze compilate per la PS5, compila `js` e controlla i simboli.

**Se si ferma, mandami i file `log_*.txt`** che lascia nella cartella del kit.

## Sulla PS5
1. copia `test.js` in `/data/ps_play/ladybird/test.js`
2. invia il binario `js` a elfldr (porta 9021)
3. leggi `/data/ps_play/logs/ladybird_js.log`

Senza argomenti (elfldr non ne passa) `js` esegue quel file e scrive lì l'uscita.

## File del kit
| File | Cosa fa |
|---|---|
| `build_fase1_js.sh` | build completa della fase 1 |
| `apply_ps5_js_only.py` | opzione `LADYBIRD_PS5_JS_ONLY`: solo le librerie e le dipendenze di `js`; script e log fissi sulla PS5 |
| `toolchain/ps5.cmake` | toolchain CMake per l'SDK della PS5 |
| `toolchain/triplets/x64-ps5.cmake` | triplet vcpkg: dipendenze statiche compilate per la PS5 |
| `cmake/ps5_js_dependencies.cmake` | le 8 dipendenze esterne della fase 1 |
| `check_symbols.sh` | funzioni importate che la PS5 non fornisce (quelle che fanno saltare a 0) |
| `ps5_compat/kernel_sys_compat.c` | le funzioni di libkernel_sys già scritte per PS Play |
| `test.js` | la prova: date, Intl, BigInt, classi con campi privati, ricorsione |

## Problemi probabili al primo giro
- **libreria standard di Rust**: è compilata per FreeBSD vero e può usare funzioni che la PS5
  non esporta; `check_symbols.sh` le elenca e si risolvono come per Wine.
- **OpenSSL e ICU** con vcpkg in compilazione incrociata verso "FreeBSD" possono richiedere
  piccole correzioni al triplet.
- **mimalloc** usa `mmap` in modi che sulla PS5 vanno verificati.

## Le fasi successive
2. **LibWeb + Skia in modalità software**: aprire una pagina e salvarla come PNG in `/data`.
3. **Processi**: Ladybird separa interfaccia, contenuto, rete e decodifica immagini. Si avviano
   come payload tramite elfldr, oppure come thread nello stesso processo.
4. **PS Play**: fotogrammi in memoria condivisa verso una pagina di PS Play, input dal pad.
