#!/usr/bin/env python3
"""Ladybird per PS5 - fase 1: modalita' "solo JavaScript" (opzione LADYBIRD_PS5_JS_ONLY).

Uso:  python3 apply_ps5_js_only.py /percorso/ladybird

Cosa fa (idempotente: si puo' rilanciare):
  1. Meta/CMake/cmake_options.cmake  -> nuova opzione LADYBIRD_PS5_JS_ONLY (OFF di default)
  2. Meta/CMake/check_for_dependencies.cmake -> con l'opzione accesa include solo
     ps5_js_dependencies.cmake (ICU, OpenSSL, fmt, simdutf, mimalloc, fast_float, libtommath, zlib)
  3. Libraries/CMakeLists.txt -> con l'opzione accesa aggiunge solo le 9 librerie che servono
     all'interprete js (calcolate seguendo target_link_libraries a catena)
  4. Utilities/CMakeLists.txt -> con l'opzione accesa costruisce solo "js", senza libedit
  5. Utilities/js.cpp -> sulla PS5 usa il ramo senza editline (come Windows e Android)
  6. vcpkg.json -> riduce le dipendenze a quelle della fase 1 (copia dell'originale in
     vcpkg.json.completo). Si modifica sul posto perche' vcpkg-configuration.json usa percorsi
     relativi alla cartella del manifesto.
"""
import json
import os
import shutil
import sys

KIT = os.path.dirname(os.path.abspath(__file__))
JS_LIBS = ["LibCore", "LibCrypto", "LibGC", "LibJS", "LibMain", "LibSyntax", "LibTextCodec",
           "LibThreading", "LibUnicode"]
VCPKG_FASE1 = {"fast-float", "fmt", "icu", "libtommath", "mimalloc", "openssl", "simdutf", "zlib"}
MARK = "LADYBIRD_PS5_JS_ONLY"


def edit(root, rel, fn):
    p = os.path.join(root, rel)
    s = open(p, encoding="utf-8").read()
    if MARK in s or "LADYBIRD_PS5" in s:
        print("  gia' applicato:", rel)
        return
    n = fn(s)
    if n == s:
        sys.exit("ERRORE: nessuna modifica possibile in " + rel + " (sorgente diverso da quello atteso)")
    open(p, "w", encoding="utf-8").write(n)
    print("  modificato:", rel)


def once(s, old, new):
    if s.count(old) != 1:
        sys.exit("ERRORE: punto di aggancio non trovato o ambiguo: " + old[:60])
    return s.replace(old, new)


def main():
    if len(sys.argv) != 2 or not os.path.isfile(os.path.join(sys.argv[1], "vcpkg.json")):
        sys.exit("uso: apply_ps5_js_only.py /percorso/ladybird")
    root = sys.argv[1]
    print("Ladybird PS5, fase 1: modalita' solo JavaScript")

    edit(root, "Meta/CMake/cmake_options.cmake", lambda s: once(
        s, 'option(ENABLE_GUI_TARGETS "Enable building GUI targets" ON)',
        'option(ENABLE_GUI_TARGETS "Enable building GUI targets" ON)\n'
        'option(LADYBIRD_PS5_JS_ONLY "PS5, fase 1: solo l\'interprete JavaScript (js)" OFF)'))

    shutil.copyfile(os.path.join(KIT, "cmake", "ps5_js_dependencies.cmake"),
                    os.path.join(root, "Meta", "CMake", "ps5_js_dependencies.cmake"))
    edit(root, "Meta/CMake/check_for_dependencies.cmake", lambda s: once(
        s, "include_guard()\n",
        "include_guard()\n\n"
        "if (LADYBIRD_PS5_JS_ONLY)\n"
        "    include(${CMAKE_CURRENT_LIST_DIR}/ps5_js_dependencies.cmake)\n"
        "    return()\n"
        "endif()\n"))

    libs = "".join("        add_subdirectory(%s)\n" % l for l in JS_LIBS)
    edit(root, "Libraries/CMakeLists.txt", lambda s:
         "if (LADYBIRD_PS5_JS_ONLY)\n" + libs.replace("        ", "    ") + "    return()\nendif()\n\n" + s)

    edit(root, "Utilities/CMakeLists.txt", lambda s:
         "if (LADYBIRD_PS5_JS_ONLY)\n"
         "    ladybird_utility(js SOURCES js.cpp LIBS LibJS LibMain)\n"
         "    return()\n"
         "endif()\n\n" + s)

    def js_cpp(s):
        s = s.replace("#if !defined(AK_OS_WINDOWS) && !defined(AK_OS_ANDROID)",
                      "#if !defined(AK_OS_WINDOWS) && !defined(AK_OS_ANDROID) && !defined(LADYBIRD_PS5)")
        s = s.replace("#if defined(AK_OS_WINDOWS) || defined(AK_OS_ANDROID)",
                      "#if defined(AK_OS_WINDOWS) || defined(AK_OS_ANDROID) || defined(LADYBIRD_PS5)")
        # elfldr non passa argomenti ai payload: script e log in posizioni fisse
        s = once(s, "ErrorOr<int> ladybird_main(Main::Arguments arguments)\n",
                 "#if defined(LADYBIRD_PS5)\n"
                 "#    include <fcntl.h>\n"
                 "#    include <unistd.h>\n"
                 "#endif\n\n"
                 "ErrorOr<int> ladybird_main(Main::Arguments arguments)\n")
        s = once(s, "    return JS::js_main(arguments.argc, arguments.argv, line_editor);\n",
                 "#if defined(LADYBIRD_PS5)\n"
                 "    // PS5: elfldr non passa argomenti. Senza argomenti si esegue uno script fisso e\n"
                 "    // l'uscita va in un file, perche' sulla console non c'e' un terminale.\n"
                 "    if (arguments.argc <= 1) {\n"
                 "        static char a0[] = \"js\";\n"
                 "        static char a1[] = \"/data/ps_play/ladybird/test.js\";\n"
                 "        static char* ps5_argv[] = { a0, a1, nullptr };\n"
                 "        int fd = ::open(\"/data/ps_play/logs/ladybird_js.log\", O_WRONLY | O_CREAT | O_TRUNC, 0666);\n"
                 "        if (fd >= 0) {\n"
                 "            ::dup2(fd, 1);\n"
                 "            ::dup2(fd, 2);\n"
                 "        }\n"
                 "        return JS::js_main(2, ps5_argv, line_editor);\n"
                 "    }\n"
                 "#endif\n"
                 "    return JS::js_main(arguments.argc, arguments.argv, line_editor);\n")
        return s
    edit(root, "Utilities/js.cpp", js_cpp)

    mp = os.path.join(root, "vcpkg.json")
    full = mp + ".completo"
    if not os.path.exists(full):
        shutil.copyfile(mp, full)
    d = json.load(open(full, encoding="utf-8"))
    name = lambda x: x if isinstance(x, str) else x.get("name")
    d["dependencies"] = [x for x in d["dependencies"] if name(x) in VCPKG_FASE1]
    found = {name(x) for x in d["dependencies"]}
    if found != VCPKG_FASE1:
        print("  ATTENZIONE: dipendenze non trovate nel manifesto:", sorted(VCPKG_FASE1 - found))
    json.dump(d, open(mp, "w", encoding="utf-8"), indent=2)
    print("  vcpkg.json: %d dipendenze (originale in vcpkg.json.completo)" % len(d["dependencies"]))
    print("fatto")


if __name__ == "__main__":
    main()
