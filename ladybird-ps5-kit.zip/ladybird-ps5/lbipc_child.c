/* PS Play - Ladybird fase 3: payload FIGLIO della prova IPC.
 * Viene lanciato dal padre tramite elfldr, come lo sarebbe un servizio di Ladybird
 * (WebContent, RequestServer...). Non eredita nulla: legge dal "biglietto" dove collegarsi. */
#include "lbipc_common.h"
#include <arpa/inet.h>
#include <netinet/in.h>

int main(void)
{
    g_logpath = LBIPC_LOGDIR "/lbipc_child.log";
    unlink(g_logpath);
    lg("==== figlio avviato (pid %d) ====", (int)getpid());

    char path[256] = {0};
    const int tf = open(LBIPC_TICKET, O_RDONLY);
    if (tf < 0)
    {
        lg("biglietto %s assente: esco", LBIPC_TICKET);
        return 1;
    }
    (void)!read(tf, path, sizeof(path) - 1);
    close(tf);
    path[strcspn(path, "\r\n")] = 0;

    /* biglietto: "unix:<percorso>" oppure "tcp:<porta>" */
    int s = -1;
    if (strncmp(path, "unix:", 5) == 0)
    {
        s = socket(AF_UNIX, SOCK_STREAM, 0);
        struct sockaddr_un a;
        memset(&a, 0, sizeof(a));
        a.sun_family = AF_UNIX;
        snprintf(a.sun_path, sizeof(a.sun_path), "%.100s", path + 5);
        if (s < 0 || connect(s, (struct sockaddr *)&a, sizeof(a)) != 0)
        {
            lg("connessione al socket locale %s fallita (errno %d %s)", path + 5, errno, errname(errno));
            return 1;
        }
    }
    else if (strncmp(path, "tcp:", 4) == 0)
    {
        s = socket(AF_INET, SOCK_STREAM, 0);
        struct sockaddr_in a;
        memset(&a, 0, sizeof(a));
        a.sin_family = AF_INET;
        a.sin_port = htons((uint16_t)atoi(path + 4));
        a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
        if (s < 0 || connect(s, (struct sockaddr *)&a, sizeof(a)) != 0)
        {
            lg("connessione TCP a 127.0.0.1:%s fallita (errno %d %s)", path + 4, errno, errname(errno));
            return 1;
        }
    }
    else
    {
        lg("biglietto non valido: \"%s\"", path);
        return 1;
    }
    lg("collegato a %s", path);
    char hello[64];
    snprintf(hello, sizeof(hello), "HELLO %d", (int)getpid());
    send_msg(s, hello, -1);

    char msg[256];
    for (;;)
    {
        int fd = -1;
        if (recv_msg(s, msg, sizeof(msg), &fd, 15000) != 0)
        {
            lg("nessun messaggio dal padre in 15 s: esco");
            break;
        }
        int m = 0, seed = 0;
        if (sscanf(msg, "MEM %d %d", &m, &seed) == 2)
        {
            char reply[200];
            uint8_t *p = fd >= 0 ? mem_map(fd) : NULL;
            if (fd < 0)
                snprintf(reply, sizeof(reply), "ERR %d nessun descrittore ricevuto", m);
            else if (!p)
                snprintf(reply, sizeof(reply), "ERR %d mmap del descrittore ricevuto fallita (errno %d)", m, errno);
            else
            {
                const int ok_a = check_half(p, 0, seed);
                fill_half(p, 1, seed); /* la meta' B la scrive il figlio */
                snprintf(reply, sizeof(reply), "OK %d %d", m, ok_a);
                munmap(p, LBIPC_MEM);
            }
            if (fd >= 0)
                close(fd);
            lg("MEM %s: %s", mem_name(m), reply);
            send_msg(s, reply, -1);
        }
        else if (strncmp(msg, "MEMNAME ", 8) == 0)
        {
            char name[200] = "", reply[260];
            if (sscanf(msg, "MEMNAME %d %d %199s", &m, &seed, name) != 3)
                snprintf(reply, sizeof(reply), "ERR messaggio non valido");
            else
            {
                const int nfd = mem_open_named(m, name);
                uint8_t *p = nfd >= 0 ? mem_map(nfd) : NULL;
                if (nfd < 0)
                    snprintf(reply, sizeof(reply), "ERR %d apertura per nome fallita (errno %d %s)", m, errno, errname(errno));
                else if (!p)
                    snprintf(reply, sizeof(reply), "ERR %d mmap fallita (errno %d %s)", m, errno, errname(errno));
                else
                {
                    const int ok_a = check_half(p, 0, seed);
                    fill_half(p, 1, seed);
                    snprintf(reply, sizeof(reply), "OK %d %d", m, ok_a);
                    munmap(p, LBIPC_MEM);
                }
                if (nfd >= 0)
                    close(nfd);
            }
            lg("MEMNAME %s: %s", mem_name(m), reply);
            send_msg(s, reply, -1);
        }
        else if (strcmp(msg, "GIVENAME") == 0)
        {
            char name[200] = "", why[120] = "", out[260];
            const int nfd = mem_create_named(MEM_SHM_NAMED, name, sizeof(name), why, sizeof(why));
            uint8_t *p = nfd >= 0 ? mem_map(nfd) : NULL;
            if (p)
            {
                fill_half(p, 0, 77);
                munmap(p, LBIPC_MEM);
                snprintf(out, sizeof(out), "TAKENAME %s", name);
            }
            else
                snprintf(out, sizeof(out), "TAKENAME - %s", why);
            if (nfd >= 0)
                close(nfd);
            send_msg(s, out, -1);
            lg("verso opposto per nome: %s", out);
        }
        else if (strcmp(msg, "GIVE") == 0)
        {
            /* verso opposto: il figlio crea la memoria e la manda al padre */
            char why[120] = "";
            int fd2 = -1;
            for (int k = 0; k < MEM_COUNT && fd2 < 0; k++)
                if (k != MEM_FILE && (fd2 = mem_create(k, why, sizeof(why))) >= 0)
                {
                    uint8_t *p = mem_map(fd2);
                    if (p)
                    {
                        fill_half(p, 0, 77);
                        munmap(p, LBIPC_MEM);
                    }
                    char out[64];
                    snprintf(out, sizeof(out), "TAKE %d", k);
                    send_msg(s, out, fd2);
                    lg("inviato al padre un blocco %s", mem_name(k));
                    close(fd2);
                }
            if (fd2 < 0)
                send_msg(s, "TAKE -1", -1);
        }
        else if (strncmp(msg, "BULK ", 5) == 0)
        {
            long want = atol(msg + 5), got = 0;
            static char buf[65536];
            /* il socket e' a flusso: il padre invia i dati solo dopo questa conferma, cosi' la
             * lettura del comando non "mangia" l'inizio dei dati */
            send_msg(s, "READY", -1);
            const long t0 = now_ms();
            while (got < want && wait_fd(s, POLLIN, 5000))
            {
                const ssize_t n = recv(s, buf, sizeof(buf), 0);
                if (n <= 0)
                    break;
                got += n;
            }
            char out[96];
            snprintf(out, sizeof(out), "BULKOK %ld %ld", got, now_ms() - t0);
            lg("ricevuti %ld byte in %ld ms", got, now_ms() - t0);
            send_msg(s, out, -1);
        }
        else if (strcmp(msg, "BYE") == 0)
        {
            lg("fine richiesta dal padre");
            break;
        }
        else if (fd >= 0)
            close(fd);
    }
    close(s);
    lg("==== figlio terminato ====");
    return 0;
}
